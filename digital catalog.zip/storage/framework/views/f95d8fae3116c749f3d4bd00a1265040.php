

<?php $__env->startSection('title', 'Product Interactions — Admin'); ?>
<?php $__env->startSection('topbar-title', 'Detailed Analytics'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Product Interactions Report</h1>
    <p>Complete breakdown of how customers are interacting with your catalog.</p>
</div>

<div class="card">
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th style="text-align:center;">Total Views</th>
                <th style="text-align:center;">Total Searches</th>
                <th style="text-align:center;">Total Compares</th>
                <th style="text-align:center;">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="font-weight:600;"><?php echo e($item->product->product_name ?? 'Deleted Product'); ?></td>
                <td style="text-align:center;"><span class="chip chip-green"><?php echo e($item->views_count); ?></span></td>
                <td style="text-align:center;">
                    <span class="chip" style="background:rgba(108,99,255,0.1); color:var(--accent);"><?php echo e($item->search_count); ?></span>
                </td>
                <td style="text-align:center;">
                    <span class="chip" style="background:rgba(245,166,35,0.1); color:#f5a623;"><?php echo e($item->compare_count); ?></span>
                </td>
                <td style="text-align:center;">
                    <?php if($item->product): ?>
                        <a href="<?php echo e(route('admin.products.edit', $item->product_id)); ?>" class="btn btn-outline btn-sm">Manage</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
    <div style="padding: 1.5rem;">
        <?php echo e($allProducts->links('pagination::simple-bootstrap-5')); ?>

    </div>
</div>

<div style="margin-top: 1.5rem;">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-outline">← Back to Dashboard</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Catalog\resources\views/admin/interactions.blade.php ENDPATH**/ ?>