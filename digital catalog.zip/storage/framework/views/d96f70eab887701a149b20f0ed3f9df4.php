<?php $__env->startSection('title', 'Edit Category — Admin'); ?>
<?php $__env->startSection('topbar-title', 'Edit Category'); ?>

<?php $__env->startSection('content'); ?>

<div style="max-width:560px;">
    <div class="card">
        <div class="card-header">
            <h3>Edit Category</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.categories.update', $category)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label>Category Name *</label>
                    <input type="text" name="category_name" class="form-control"
                           value="<?php echo e(old('category_name', $category->category_name)); ?>" required>
                    <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label>Category Image</label>
                    <?php if($category->category_image): ?>
                        <div style="margin-bottom:0.6rem;">
                            <img src="<?php echo e(asset('storage/'.$category->category_image)); ?>" style="width:80px;height:80px;object-fit:cover;border-radius:10px;border:1px solid var(--border);">
                            <p style="font-size:0.75rem;color:var(--muted);margin-top:0.3rem;">Upload a new image to replace</p>
                        </div>
                    <?php endif; ?>
                    <input type="file" name="category_image" class="form-control" accept="image/*">
                    <?php $__errorArgs = ['category_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div style="display:flex;gap:0.75rem;margin-top:1.5rem;">
                    <button type="submit" class="btn btn-primary">Update Category</button>
                    <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Dialog\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>