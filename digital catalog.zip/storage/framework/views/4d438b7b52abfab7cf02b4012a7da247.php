<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Admin — Mood Set-up Studio'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        :root {
    --sidebar-w: 252px;
    --red:       #ce3530;
    --red-dark:  #a32420;
    --red-pale:  #fdf1f0;
    --teal:      #004b4e;
    --teal-mid:  #006b6f;
    --teal-pale: #e6f4f4;
    --ink:       #1c1c1e;
    --ink-2:     #3a3a3c;
    --ghost:     #f2f2f7;
    --line:      rgba(0,0,0,0.08);
    --white:     #ffffff;
    --success:   #00a876;
    --danger:    #e03355;
    --warn:      #d97706;
    --spring:    cubic-bezier(.34,1.56,.64,1);
    --ease:      cubic-bezier(.25,.8,.25,1);
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'DM Sans', sans-serif;
    background: var(--ghost);
    color: var(--ink);
    display: flex;
    min-height: 100vh;
}
h1,h2,h3,h4,h5 { letter-spacing: -0.2px; }

/* ── SIDEBAR ── */
.sidebar {
    width: var(--sidebar-w); flex-shrink: 0;
    background: linear-gradient(175deg, #004b4e 0%, #003538 100%);
    display: flex; flex-direction: column;
    position: fixed; height: 100vh; top: 0; left: 0;
    z-index: 50;
    border-right: 0.5px solid rgba(0,0,0,0.15);
}
.sidebar-logo {
    padding: 1.4rem 1.4rem 1.2rem;
    border-bottom: 0.5px solid rgba(255,255,255,0.08);
}
.sidebar-logo a {
    font-weight: 700; font-size: 1.05rem;
    color: var(--white); text-decoration: none;
    display: block; line-height: 1.2; letter-spacing: -0.3px;
}
.sidebar-logo a em { font-style: normal; color: #ff6b68; }
.sidebar-logo p {
    font-size: 0.65rem; color: rgba(255,255,255,0.35);
    margin-top: 0.2rem; text-transform: uppercase;
    letter-spacing: 0.12em; font-weight: 600;
}

.sidebar-nav { padding: 1rem 0.65rem; flex: 1; overflow-y: auto; }
.nav-label {
    font-size: 0.6rem; text-transform: uppercase; letter-spacing: 0.12em;
    color: rgba(255,255,255,0.3); padding: 0.65rem 0.75rem 0.35rem;
    margin-top: 0.2rem; font-weight: 700;
}
.sidebar-nav a {
    display: flex; align-items: center; gap: 0.65rem;
    padding: 0.58rem 0.75rem; border-radius: 8px;
    color: rgba(255,255,255,0.55); text-decoration: none; font-size: 0.85rem;
    font-weight: 500;
    transition: all 0.15s; margin-bottom: 0.08rem;
}
.sidebar-nav a:hover {
    background: rgba(255,255,255,0.08); color: var(--white);
}
.sidebar-nav a.active {
    background: rgba(206,53,48,0.85); color: var(--white);
    box-shadow: 0 2px 12px rgba(206,53,48,0.3);
}
.sidebar-nav svg { flex-shrink: 0; opacity: 0.75; }
.sidebar-nav a.active svg { opacity: 1; }

.sidebar-footer {
    padding: 1rem 1.4rem;
    border-top: 0.5px solid rgba(255,255,255,0.08);
}
.sidebar-footer .user-name {
    font-size: 0.8rem; font-weight: 600; color: var(--white);
    margin-bottom: 0.25rem; letter-spacing: -0.1px;
}
.sidebar-footer button {
    background: none; border: none; color: rgba(255,255,255,0.35);
    cursor: pointer; font-size: 0.75rem; padding: 0;
    transition: color 0.15s; font-family: inherit;
}
.sidebar-footer button:hover { color: #ff6b68; }

/* ── MAIN WRAP ── */
.main-wrap {
    margin-left: var(--sidebar-w); flex: 1;
    display: flex; flex-direction: column; min-height: 100vh;
}
.topbar {
    height: 60px; border-bottom: 0.5px solid rgba(0,0,0,0.08);
    padding: 0 2rem;
    display: flex; align-items: center; justify-content: space-between;
    background: rgba(255,255,255,0.75);
    backdrop-filter: blur(16px) saturate(180%);
    -webkit-backdrop-filter: blur(16px) saturate(180%);
    position: sticky; top: 0; z-index: 40;
}
.topbar-left { display: flex; align-items: center; gap: 0.75rem; }
.topbar-breadcrumb {
    font-size: 0.75rem; color: #8e8e93;
    display: flex; align-items: center; gap: 0.4rem;
}
.topbar-breadcrumb span { color: #8e8e93; }
.topbar-breadcrumb strong { color: var(--ink); font-weight: 600; }
.topbar h2 { font-size: 0.975rem; font-weight: 700; color: var(--ink); letter-spacing: -0.2px; }
.topbar-user { display: flex; align-items: center; gap: 0.6rem; }
.topbar-avatar {
    width: 30px; height: 30px; border-radius: 50%;
    background: linear-gradient(135deg, #004b4e, #006b6f);
    color: var(--white);
    display: flex; align-items: center; justify-content: center;
    font-size: 0.68rem; font-weight: 700;
    box-shadow: 0 1px 4px rgba(0,75,78,0.3);
}
.topbar-name { font-size: 0.83rem; font-weight: 500; color: var(--ink); }

.page-content { padding: 2rem; flex: 1; max-width: 1200px; width: 100%; }

/* ── CARDS ── */
.card {
    background: rgba(255,255,255,0.88);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 0.5px solid rgba(0,0,0,0.07);
    border-radius: 14px; overflow: hidden;
}
.card-body { padding: 1.4rem; }
.card-header {
    padding: 1rem 1.4rem; border-bottom: 0.5px solid rgba(0,0,0,0.07);
    display: flex; align-items: center; justify-content: space-between;
}
.card-header h3 { font-size: 0.9rem; font-weight: 700; letter-spacing: -0.2px; }

/* ── TABLES ── */
table { width: 100%; border-collapse: collapse; }
th, td { padding: 0.8rem 1rem; text-align: left; border-bottom: 0.5px solid rgba(0,0,0,0.06); font-size: 0.875rem; }
th {
    font-size: 0.68rem; color: #8e8e93; text-transform: uppercase;
    letter-spacing: 0.07em; font-weight: 600; background: rgba(242,242,247,0.7);
}
tr:last-child td { border-bottom: none; }
tbody tr { transition: background 0.15s; }
tbody tr:hover { background: rgba(0,75,78,0.03); }

/* ── STAT CARDS ── */
.stats-grid {
    display: grid; grid-template-columns: repeat(4, 1fr);
    gap: 0.875rem; margin-bottom: 1.75rem;
}
.stat-card {
    background: rgba(255,255,255,0.88);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 0.5px solid rgba(0,0,0,0.07);
    border-radius: 14px; padding: 1.25rem 1.4rem;
    position: relative; overflow: hidden;
    transition: transform 0.2s var(--spring), box-shadow 0.2s;
    cursor: default;
}
.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}
.stat-card::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2.5px;
}
.stat-card.teal::before  { background: var(--teal); }
.stat-card.red::before   { background: var(--red); }
.stat-card.danger::before { background: var(--danger); }
.stat-card.warn::before  { background: var(--warn); }
.stat-card .label {
    font-size: 0.68rem; color: #8e8e93; text-transform: uppercase;
    letter-spacing: 0.09em; font-weight: 700; margin-bottom: 0.55rem;
}
.stat-card .value {
    font-size: 2.1rem; font-weight: 700; line-height: 1; letter-spacing: -0.5px;
}
.stat-card .sub { font-size: 0.72rem; color: #8e8e93; margin-top: 0.35rem; }

/* ── BUTTONS ── */
.btn {
    display: inline-flex; align-items: center; gap: 0.4rem;
    padding: 0.52rem 1.1rem; border-radius: 8px; border: 0.5px solid transparent;
    font-size: 0.82rem; font-weight: 600; cursor: pointer;
    text-decoration: none; transition: all 0.2s;
    font-family: inherit; letter-spacing: -0.1px;
}
.btn-primary {
    background: var(--red); color: var(--white); border-color: var(--red);
}
.btn-primary:hover { background: var(--red-dark); transform: scale(1.02); }
.btn-teal { background: var(--teal); color: var(--white); border-color: var(--teal); }
.btn-teal:hover { background: var(--teal-mid); transform: scale(1.02); }
.btn-outline {
    background: rgba(255,255,255,0.7);
    backdrop-filter: blur(8px);
    border-color: rgba(0,0,0,0.1); color: var(--ink);
}
.btn-outline:hover {
    border-color: rgba(0,75,78,0.25); color: var(--teal);
    background: rgba(0,75,78,0.06);
}
.btn-danger { background: var(--danger); color: var(--white); border-color: var(--danger); }
.btn-danger:hover { opacity: 0.88; transform: scale(1.01); }
.btn-sm { padding: 0.28rem 0.7rem; font-size: 0.75rem; border-radius: 6px; }

/* ── CHIPS ── */
.chip {
    display: inline-flex; align-items: center; justify-content: center;
    padding: 0.18rem 0.6rem; border-radius: 20px;
    font-size: 0.68rem; font-weight: 700; letter-spacing: 0.02em;
}
.chip-green  { background: rgba(0,168,118,0.1); color: var(--success); }
.chip-red    { background: rgba(206,53,48,0.1); color: var(--red); }
.chip-teal   { background: rgba(0,75,78,0.1); color: var(--teal); }
.chip-amber  { background: rgba(217,119,6,0.1); color: var(--warn); }

/* ── FORMS ── */
.form-group { margin-bottom: 1.2rem; }
.form-group label {
    display: block; font-size: 0.8rem; color: var(--ink-2);
    font-weight: 500; margin-bottom: 0.38rem;
}
.form-control {
    width: 100%; padding: 0.62rem 0.9rem;
    background: rgba(255,255,255,0.9);
    border: 0.5px solid rgba(0,0,0,0.12);
    border-radius: 8px; color: var(--ink); font-size: 0.875rem;
    outline: none; transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
    font-family: inherit;
}
.form-control:focus {
    border-color: var(--teal);
    background: var(--white);
    box-shadow: 0 0 0 3px rgba(0,75,78,0.1);
}
textarea.form-control { resize: vertical; min-height: 100px; }
.form-error { color: var(--danger); font-size: 0.76rem; margin-top: 0.28rem; }

/* ── FLASH ── */
.flash {
    padding: 0.8rem 1.2rem; border-radius: 10px; margin-bottom: 1.4rem;
    font-size: 0.875rem; border-left: 3px solid;
}
.flash.success { background: rgba(0,168,118,0.08); border-color: var(--success); color: #007a56; }
.flash.error   { background: rgba(206,53,48,0.08); border-color: var(--red); color: var(--red-dark); }

/* ── GRID ── */
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1.25rem; }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-logo">
        <a href="<?php echo e(route('admin.dashboard')); ?>">Mood&nbsp;Set-up&nbsp;<em>Studio</em></a>
        <p>Admin Panel</p>
    </div>
    <nav class="sidebar-nav">
        <p class="nav-label">Overview</p>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
            Dashboard
        </a>
        <a href="<?php echo e(route('admin.interactions')); ?>" class="<?php echo e(request()->routeIs('admin.interactions*') ? 'active' : ''); ?>">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-6"/></svg>
            Analytics
        </a>

        <p class="nav-label">Catalog</p>
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="<?php echo e(request()->routeIs('admin.categories.*') ? 'active' : ''); ?>">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"/></svg>
            Categories
        </a>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="<?php echo e(request()->routeIs('admin.products.*') ? 'active' : ''); ?>">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
            Products
        </a>

        <p class="nav-label">Store</p>
        <a href="<?php echo e(route('home')); ?>" target="_blank">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
            View Store
        </a>
    </nav>
    <div class="sidebar-footer">
        <div class="user-name"><?php echo e(auth()->user()->name ?? 'Admin'); ?></div>
        <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline;">
            <?php echo csrf_field(); ?>
            <button type="submit">Sign out</button>
        </form>
    </div>
</aside>

<div class="main-wrap">
    <div class="topbar">
        <div class="topbar-left">
            <div class="topbar-breadcrumb">
                <span>Admin</span>
                <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
                <strong><?php echo $__env->yieldContent('topbar-title', 'Dashboard'); ?></strong>
            </div>
        </div>
        <div class="topbar-user">
            <div class="topbar-avatar"><?php echo e(strtoupper(substr(auth()->user()->name ?? 'A', 0, 2))); ?></div>
            <span class="topbar-name"><?php echo e(auth()->user()->name ?? 'Admin'); ?></span>
        </div>
    </div>
    <div class="page-content">
        <?php if(session('success')): ?>
            <div class="flash success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="flash error"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\wamp64\www\Digital_Catalog\resources\views/layouts/admin.blade.php ENDPATH**/ ?>