<?php $__env->startSection('title', 'Compare Products — TechVault'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <h1>Compare Products</h1>
    <p>Side-by-side comparison</p>
</div>

<?php if($products->isEmpty()): ?>
    <div style="text-align:center;padding:4rem 0;">
        <p style="color:var(--muted);margin-bottom:1rem;">No products selected for comparison.</p>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Browse Products</a>
    </div>
<?php else: ?>

<div style="overflow-x:auto;">
    <table style="min-width:600px;">
        <thead>
            <tr style="border-bottom:1px solid var(--border);">
                <th style="width:180px;color:var(--muted);">Specification</th>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th>
                        <a href="<?php echo e(route('product.show', $p)); ?>" style="text-decoration:none;color:var(--text);">
                            <div style="margin-bottom:0.5rem;">
                                <img src="<?php echo e(asset('storage/'.$p->product_image)); ?>" alt="<?php echo e($p->product_name); ?>"
                                     style="width:80px;height:80px;object-fit:cover;border-radius:10px;border:1px solid var(--border);">
                            </div>
                            <p style="font-family:'Syne',sans-serif;font-weight:600;font-size:0.9rem;"><?php echo e($p->product_name); ?></p>
                        </a>
                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Brand</td>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="font-size:0.9rem;"><?php echo e($p->brand); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Category</td>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="font-size:0.9rem;"><?php echo e($p->category->category_name); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Price</td>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="font-size:1rem;font-weight:700;color:var(--accent);">$<?php echo e(number_format($p->price, 2)); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Stock</td>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="font-size:0.9rem;"><?php echo e($p->stock_quantity); ?> units</td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Status</td>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td>
                        <?php if($p->status === 'available'): ?>
                            <span class="chip chip-green" style="font-size:0.75rem;">Available</span>
                        <?php else: ?>
                            <span class="chip chip-red" style="font-size:0.75rem;">Out of Stock</span>
                        <?php endif; ?>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Description</td>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="font-size:0.85rem;color:var(--muted);max-width:220px;"><?php echo e(Str::limit($p->description, 120)); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <td></td>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><a href="<?php echo e(route('product.show', $p)); ?>" class="btn btn-outline btn-sm">View Details</a></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </tbody>
    </table>
</div>

<div style="margin-top:2rem;text-align:center;">
    <button class="btn btn-outline" onclick="clearCompare();window.location='<?php echo e(route('home')); ?>'">
        Clear & Browse More
    </button>
</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Dialog\resources\views/customer/compare.blade.php ENDPATH**/ ?>