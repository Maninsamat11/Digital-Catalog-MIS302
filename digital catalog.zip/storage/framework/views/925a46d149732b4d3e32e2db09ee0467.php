<?php $__env->startSection('title', $product->product_name . ' — TechVault'); ?>

<?php $__env->startSection('content'); ?>


<div style="margin-bottom:2rem;font-size:0.85rem;color:var(--muted);">
    <a href="<?php echo e(route('home')); ?>" style="color:var(--muted);text-decoration:none;">Home</a>
    <span style="margin:0 0.5rem;">/</span>
    <a href="<?php echo e(route('category.show', $product->category)); ?>" style="color:var(--muted);text-decoration:none;"><?php echo e($product->category->category_name); ?></a>
    <span style="margin:0 0.5rem;">/</span>
    <span style="color:var(--text);"><?php echo e($product->product_name); ?></span>
</div>


<div style="display:grid;grid-template-columns:1fr 1fr;gap:3rem;margin-bottom:4rem;">

    
    <div>
        <div style="background:var(--surface);border:1px solid var(--border);border-radius:16px;overflow:hidden;aspect-ratio:1;">
            <img src="<?php echo e(asset('storage/'.$product->product_image)); ?>" alt="<?php echo e($product->product_name); ?>"
                 style="width:100%;height:100%;object-fit:cover;">
        </div>
    </div>

    
    <div>
        <p style="font-size:0.78rem;color:var(--accent2);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.4rem;"><?php echo e($product->brand); ?></p>
        <h1 style="font-size:2rem;font-weight:800;line-height:1.2;margin-bottom:1rem;"><?php echo e($product->product_name); ?></h1>

        <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;">
            <span style="font-size:2.2rem;font-weight:800;color:var(--accent);">$<?php echo e(number_format($product->price, 2)); ?></span>
            <?php if($product->status === 'available'): ?>
                <span class="chip chip-green">In Stock (<?php echo e($product->stock_quantity); ?>)</span>
            <?php else: ?>
                <span class="chip chip-red">Out of Stock</span>
            <?php endif; ?>
        </div>

        <div style="border-top:1px solid var(--border);padding-top:1.25rem;margin-bottom:1.5rem;">
            <p style="color:var(--muted);line-height:1.7;"><?php echo e($product->description); ?></p>
        </div>

        
        <div class="card" style="margin-bottom:1.5rem;">
            <table>
                <tbody>
                    <tr>
                        <td style="color:var(--muted);width:40%;font-size:0.875rem;">Category</td>
                        <td style="font-size:0.875rem;"><?php echo e($product->category->category_name); ?></td>
                    </tr>
                    <tr>
                        <td style="color:var(--muted);font-size:0.875rem;">Brand</td>
                        <td style="font-size:0.875rem;"><?php echo e($product->brand); ?></td>
                    </tr>
                    <tr>
                        <td style="color:var(--muted);font-size:0.875rem;">Stock</td>
                        <td style="font-size:0.875rem;"><?php echo e($product->stock_quantity); ?> units</td>
                    </tr>
                    <tr>
                        <td style="color:var(--muted);font-size:0.875rem;">Status</td>
                        <td>
                            <?php if($product->status === 'available'): ?>
                                <span class="chip chip-green" style="font-size:0.75rem;">Available</span>
                            <?php else: ?>
                                <span class="chip chip-red" style="font-size:0.75rem;">Out of Stock</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        
        <div style="display:flex;gap:0.75rem;">
            <button class="btn btn-primary" onclick="toggleCompare('<?php echo e($product->id); ?>', '<?php echo e(addslashes($product->product_name)); ?>')">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-6"/></svg>
                Add to Compare
            </button>
            <a href="<?php echo e(route('search', ['category' => $product->category_id])); ?>" class="btn btn-outline">
                Browse Similar
            </a>
        </div>
    </div>
</div>


<?php if($related->isNotEmpty()): ?>
<section>
    <h2 style="font-size:1.3rem;font-weight:700;margin-bottom:1.25rem;">Related Products</h2>
    <div class="product-grid">
        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials.product-card', ['product' => $relProduct], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Dialog\resources\views/customer/product.blade.php ENDPATH**/ ?>