<?php $__env->startSection('title', 'Products — Admin'); ?>
<?php $__env->startSection('topbar-title', 'Products'); ?>

<?php $__env->startSection('content'); ?>

<!-- Filter Bar -->
<div class="card" style="margin-bottom: 1.5rem; padding: 1rem;">
    <form action="<?php echo e(route('admin.products.index')); ?>" method="GET" style="display: flex; gap: 1rem; align-items: flex-end; flex-wrap: wrap;">
        
        <!-- Search -->
        <div style="flex: 1; min-width: 200px;">
            <label style="font-size: 0.75rem; color: var(--muted); margin-bottom: 0.4rem; display: block;">Search Name or Brand</label>
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Search...">
        </div>

        <!-- Category Filter -->
        <div style="width: 180px;">
            <label style="font-size: 0.75rem; color: var(--muted); margin-bottom: 0.4rem; display: block;">Category</label>
            <select name="category" class="form-control">
                <option value="">All Categories</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category') == $cat->id ? 'selected' : ''); ?>>
                        <?php echo e($cat->category_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Brand Filter (Manual input or Select) -->
        <div style="width: 150px;">
            <label style="font-size: 0.75rem; color: var(--muted); margin-bottom: 0.4rem; display: block;">Brand</label>
            <input type="text" name="brand" value="<?php echo e(request('brand')); ?>" class="form-control" placeholder="Brand name">
        </div>

        <div style="display: flex; gap: 0.5rem;">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-outline">Clear</a>
        </div>
    </form>
</div>



<div class="card">
    <div class="card-header">
        <h3>All Products (<?php echo e($products->count()); ?>)</h3>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary btn-sm">+ New Product</a>
    </div>
    <table>
        <thead>
            <tr>
                <th>Image</th>
                <th>Product</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="clickable-row" 
                data-id="<?php echo e($product->id); ?>" 
                data-name="<?php echo e($product->product_name); ?>"
                data-brand="<?php echo e($product->brand); ?>"
                data-category="<?php echo e($product->category->category_name); ?>"
                data-price="<?php echo e(number_format($product->price, 2)); ?>"
                data-stock="<?php echo e($product->stock_quantity); ?>"
                data-description="<?php echo e($product->description); ?>"
                data-status="<?php echo e($product->status); ?>"
                data-image="<?php echo e(asset('storage/'.$product->product_image)); ?>"
                style="cursor: pointer;">
                
                <td>
                    <img src="<?php echo e(asset('storage/'.$product->product_image)); ?>" style="width:48px;height:48px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">
                </td>
                <td>
                    <p style="font-weight:600;font-size:0.875rem;"><?php echo e($product->product_name); ?></p>
                    <p style="color:var(--muted);font-size:0.75rem;"><?php echo e($product->brand); ?></p>
                </td>
                <td style="color:var(--muted);font-size:0.85rem;"><?php echo e($product->category->category_name); ?></td>
                <td style="font-weight:600;color:var(--accent);">$<?php echo e(number_format($product->price, 2)); ?></td>
                <td style="font-size:0.875rem;"><?php echo e($product->stock_quantity); ?></td>
                <td>
                    <?php if($product->status === 'available'): ?>
                        <span class="chip chip-green">Available</span>
                    <?php else: ?>
                        <span class="chip chip-red">Out of Stock</span>
                    <?php endif; ?>
                </td>
                <td onclick="event.stopPropagation();"> <!-- This prevents the pop-up when clicking buttons -->
                    <div style="display:flex;gap:0.5rem;">
                        <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="btn btn-outline btn-sm">Edit</a>
                        <form method="POST" action="<?php echo e(route('admin.products.destroy', $product)); ?>" onsubmit="return confirm('Delete this product?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:2.5rem;">No products yet. <a href="<?php echo e(route('admin.products.create')); ?>" style="color:var(--accent);">Add one</a>.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>


<!-- Product Detail Modal -->
<div id="productModal" class="modal-overlay">
    <div class="modal-card">
        <button class="close-modal">&times;</button>
        <div class="modal-body">
            <div class="modal-image">
                <img id="modalImg" src="" alt="Product">
            </div>
            <div class="modal-info">
                <span id="modalBrand" class="brand-badge">BRAND</span>
                <h2 id="modalName">Product Name</h2>
                <p id="modalCategory" style="color: var(--muted); font-size: 0.9rem; margin-bottom: 1rem;">Category</p>
                
                <div class="modal-price-row">
                    <span id="modalPrice" class="modal-price">$0.00</span>
                    <span id="modalStatus" class="chip">Status</span>
                </div>

                <div class="modal-description">
                    <h4>Description</h4>
                    <p id="modalDesc">No description available.</p>
                </div>

                <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--border);">
                    <p style="font-size: 0.85rem; color: var(--muted);">Stock Quantity: <strong id="modalStock" style="color: var(--text);">0</strong></p>
                </div>
                <div class="modal-footer-actions" style="margin-top: 2rem; display: flex; gap: 0.75rem; padding-top: 1.5rem; border-top: 1px solid var(--border);">
    
    <!-- Edit Button -->
    <a href="#" id="modalEditLink" class="btn btn-outline" style="flex: 1; justify-content: center;">
        Edit Product
    </a>

    <!-- Delete Form -->
    <form id="modalDeleteForm" method="POST" action="" onsubmit="return confirm('Delete this product permanently?')">
        <?php echo csrf_field(); ?> 
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger">Delete</button>
    </form>
    </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Modal Styles */
.modal-overlay {
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.5); backdrop-filter: blur(4px);
    display: none; align-items: center; justify-content: center;
    z-index: 1000; padding: 2rem;
}
.modal-overlay.active { display: flex; }

.modal-card {
    background: var(--card); width: 100%; max-width: 800px;
    border-radius: 20px; position: relative; overflow: hidden;
    animation: modalIn 0.3s ease-out; box-shadow: 0 20px 50px rgba(0,0,0,0.2);
}
@keyframes modalIn { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

.close-modal {
    position: absolute; top: 1rem; right: 1.5rem; background: none; border: none;
    font-size: 2rem; color: var(--muted); cursor: pointer; z-index: 10;
}
.close-modal:hover { color: var(--accent); }

.modal-body { display: grid; grid-template-columns: 1fr 1.2fr; }

.modal-image { background: #f9f9f9; display: flex; align-items: center; justify-content: center; }
.modal-image img { width: 100%; height: 100%; object-fit: cover; max-height: 500px; }

.modal-info { padding: 2.5rem; }
.brand-badge { color: var(--accent2); font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; }
#modalName { font-family: 'Syne', sans-serif; font-size: 1.8rem; margin: 0.5rem 0; line-height: 1.2; }
.modal-price-row { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
.modal-price { font-size: 1.5rem; font-weight: 800; color: var(--accent); }

.modal-description h4 { font-size: 0.85rem; text-transform: uppercase; color: var(--muted); margin-bottom: 0.5rem; }
.modal-description p { font-size: 0.95rem; color: #444; line-height: 1.6; max-height: 150px; overflow-y: auto; }

@media (max-width: 768px) {
    .modal-body { grid-template-columns: 1fr; }
    .modal-info { padding: 1.5rem; }
}
</style>
<?php $__env->stopSection(); ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('productModal');
    const closeBtn = document.querySelector('.close-modal');
    const rows = document.querySelectorAll('.clickable-row');

    rows.forEach(row => {
        row.addEventListener('click', function() {
            // 1. Get data from attributes
            const id = this.dataset.id; // <--- Make sure this is here
            const name = this.dataset.name;
            const brand = this.dataset.brand;
            const category = this.dataset.category;
            const price = this.dataset.price;
            const stock = this.dataset.stock;
            const desc = this.dataset.description;
            const status = this.dataset.status;
            const img = this.dataset.image;

            // 2. Fill Text Content
            document.getElementById('modalName').innerText = name;
            document.getElementById('modalBrand').innerText = brand;
            document.getElementById('modalCategory').innerText = category;
            document.getElementById('modalPrice').innerText = '$' + price;
            document.getElementById('modalStock').innerText = stock;
            document.getElementById('modalDesc').innerText = desc;
            document.getElementById('modalImg').src = img;

            // 3. UPDATE THE LINKS (This is what was missing)
            // This sets the Edit button to go to /admin/products/[ID]/edit
            document.getElementById('modalEditLink').href = `/admin/products/${id}/edit`;
            
            // This sets the Delete form to submit to /admin/products/[ID]
            document.getElementById('modalDeleteForm').action = `/admin/products/${id}`;

            // 4. Handle Status Chip color
            const statusEl = document.getElementById('modalStatus');
            statusEl.innerText = status === 'available' ? 'Available' : 'Out of Stock';
            statusEl.className = status === 'available' ? 'chip chip-green' : 'chip chip-red';

            // 5. Show Modal
            modal.classList.add('active');
        });
    });

    // Close Modal Logic
    closeBtn.onclick = () => modal.classList.remove('active');
    window.onclick = (event) => { if (event.target == modal) modal.classList.remove('active'); }
});
</script>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Dialog\resources\views/admin/products/index.blade.php ENDPATH**/ ?>