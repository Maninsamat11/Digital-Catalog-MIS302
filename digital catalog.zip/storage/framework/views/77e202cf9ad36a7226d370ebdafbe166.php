<?php $__env->startSection('title', 'TechVault — Digital Catalog'); ?>

<?php $__env->startSection('content'); ?>


<section style="padding: 4rem 0 3rem; text-align: center; position: relative;">
    <div style="position:absolute;inset:0;background:radial-gradient(ellipse 60% 50% at 50% 0%, rgba(108,99,255,0.12) 0%, transparent 70%);pointer-events:none;"></div>
    <p style="font-size:0.8rem;color:var(--accent2);text-transform:uppercase;letter-spacing:0.15em;margin-bottom:0.75rem;">In-Store Digital Catalog</p>
    <h1 style="font-size:clamp(2.2rem,5vw,3.5rem);font-weight:800;line-height:1.1;margin-bottom:1rem;">
        Discover the Latest<br><span style="color:var(--accent2);">Electronics</span>
    </h1>
    <p style="color:var(--muted);font-size:1.05rem;max-width:480px;margin:0 auto 2rem;">Browse our full product range, compare specs, and find what you're looking for — without waiting for staff.</p>
    <form action="<?php echo e(route('search')); ?>" method="GET" style="display:flex;gap:0.75rem;justify-content:center;max-width:500px;margin:auto;">
        <input type="text" name="q" placeholder="What are you looking for?" class="form-control" style="flex:1;">
        <button class="btn btn-primary">Search</button>
    </form>
</section>


<section style="margin-bottom: 3.5rem;">
    <h2 style="font-size:1.3rem;font-weight:700;margin-bottom:1.25rem;">Browse Categories</h2>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:1rem;">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('category.show', $cat)); ?>" style="text-decoration:none;">
            <div class="card" style="padding:1.5rem;text-align:center;">
                <?php if($cat->category_image): ?>
                    <img src="<?php echo e(asset('storage/'.$cat->category_image)); ?>" alt="" style="width:56px;height:56px;object-fit:cover;border-radius:10px;margin-bottom:0.75rem;">
                <?php else: ?>
                    <div style="width:56px;height:56px;border-radius:10px;background:rgba(108,99,255,0.1);margin:0 auto 0.75rem;display:flex;align-items:center;justify-content:center;">
                        <svg width="24" height="24" fill="none" stroke="var(--accent)" stroke-width="1.5" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
                    </div>
                <?php endif; ?>
                <p style="font-family:'Syne',sans-serif;font-weight:600;font-size:0.95rem;color:var(--text);"><?php echo e($cat->category_name); ?></p>
                <p style="font-size:0.78rem;color:var(--muted);margin-top:0.2rem;"><?php echo e($cat->products_count); ?> products</p>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>


<section>
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem;">
        <h2 style="font-size:1.3rem;font-weight:700;">Featured Products</h2>
        <a href="<?php echo e(route('search')); ?>" style="font-size:0.85rem;color:var(--accent);text-decoration:none;">View All →</a>
    </div>
    <div class="product-grid">
        <?php $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Dialog\resources\views/customer/home.blade.php ENDPATH**/ ?>