<?php $__env->startSection('title', $category->category_name . ' — TechVault'); ?>

<?php $__env->startSection('content'); ?>

<div style="margin-bottom:2rem;">
    <a href="<?php echo e(route('home')); ?>" style="color:var(--muted);text-decoration:none;font-size:0.85rem;">Home</a>
    <span style="color:var(--muted);margin:0 0.5rem;">/</span>
    <span style="font-size:0.85rem;color:var(--text);"><?php echo e($category->category_name); ?></span>
</div>

<div class="page-header">
    <h1><?php echo e($category->category_name); ?></h1>
    <p><?php echo e($products->count()); ?> products available</p>
</div>

<?php if($products->isEmpty()): ?>
    <div style="text-align:center;padding:4rem 0;">
        <p style="color:var(--muted);">No products in this category yet.</p>
    </div>
<?php else: ?>
    <div class="product-grid">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Catalog\resources\views/customer/category.blade.php ENDPATH**/ ?>