<?php $__env->startSection('title', 'Dashboard — Admin'); ?>
<?php $__env->startSection('topbar-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>


<div class="stats-grid">
    <div class="stat-card">
        <p class="label">Total Products</p>
        <p class="value" style="color:var(--accent);"><?php echo e($totalProducts); ?></p>
        <p class="sub">Across all categories</p>
    </div>
    <div class="stat-card">
        <p class="label">Categories</p>
        <p class="value" style="color:var(--accent2);"><?php echo e($totalCategories); ?></p>
        <p class="sub">Active categories</p>
    </div>
    <div class="stat-card">
        <p class="label">Out of Stock</p>
        <p class="value" style="color:var(--danger);"><?php echo e($outOfStock); ?></p>
        <p class="sub">Need restocking</p>
    </div>
    <div class="stat-card">
        <p class="label">Total Interactions</p>
        <p class="value" style="color:#f5a623;"><?php echo e($totalInteractions); ?></p>
        <p class="sub">Views, searches, compares</p>
    </div>
</div>

<div class="grid-2" style="margin-bottom:1.5rem;">

    
    <div class="card">
        <div class="card-header">
            <h3>Most Viewed Products</h3>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Views</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $mostViewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->product->product_name ?? '—'); ?></td>
                    <td><span class="chip chip-green"><?php echo e($item->views); ?></span></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="2" style="color:var(--muted);text-align:center;padding:2rem;">No data yet</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3>Interactions by Type</h3>
        </div>
        <div class="card-body">
            <?php $types = ['view' => 'var(--accent)', 'search' => 'var(--accent2)', 'compare' => '#f5a623']; ?>
            <?php $__empty_1 = true; $__currentLoopData = $interactionsByType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $total = $interactionsByType->sum(); $pct = $total > 0 ? round($count / $total * 100) : 0; ?>
            <div style="margin-bottom:1.25rem;">
                <div style="display:flex;justify-content:space-between;font-size:0.85rem;margin-bottom:0.4rem;">
                    <span style="text-transform:capitalize;"><?php echo e($type); ?></span>
                    <span style="color:var(--muted);"><?php echo e($count); ?> (<?php echo e($pct); ?>%)</span>
                </div>
                <div style="background:var(--border);border-radius:4px;height:8px;overflow:hidden;">
                    <div style="height:100%;width:<?php echo e($pct); ?>%;background:<?php echo e($types[$type] ?? 'var(--accent)'); ?>;border-radius:4px;transition:width 0.6s ease;"></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="color:var(--muted);text-align:center;padding:2rem 0;font-size:0.875rem;">No interactions recorded yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="card">
    <div class="card-header">
        <h3>Daily Interactions (Last 7 Days)</h3>
    </div>
    <div class="card-body">
        <?php if($dailyInteractions->isEmpty()): ?>
            <p style="color:var(--muted);text-align:center;padding:2rem 0;font-size:0.875rem;">No data for the past 7 days.</p>
        <?php else: ?>
        <div style="display:flex;align-items:flex-end;gap:0.75rem;height:140px;padding-bottom:1.5rem;position:relative;">
            <?php $maxCount = $dailyInteractions->max('count') ?: 1; ?>
            <?php $__currentLoopData = $dailyInteractions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $height = max(8, round(($day->count / $maxCount) * 110)); ?>
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:0.4rem;">
                <span style="font-size:0.7rem;color:var(--muted);"><?php echo e($day->count); ?></span>
                <div style="width:100%;height:<?php echo e($height); ?>px;background:linear-gradient(to top, var(--accent), rgba(220, 218, 248, 0.3));border-radius:6px 6px 0 0;"></div>
                <span style="font-size:0.65rem;color:var(--muted);white-space:nowrap;"><?php echo e(\Carbon\Carbon::parse($day->date)->format('M d')); ?></span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Dialog\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>