<div class="card product-card">
    <?php if($product->status === 'out_of_stock'): ?>
        <span class="badge">Out of Stock</span>
    <?php endif; ?>
    <button class="compare-check" data-id="<?php echo e($product->id); ?>" onclick="toggleCompare('<?php echo e($product->id); ?>', '<?php echo e(addslashes($product->product_name)); ?>')">
        <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-6"/></svg>
        Compare
    </button>
    <a href="<?php echo e(route('product.show', $product)); ?>" style="text-decoration:none;color:inherit;">
        <div class="img-wrap">
            <img src="<?php echo e(asset('storage/'.$product->product_image)); ?>" alt="<?php echo e($product->product_name); ?>" loading="lazy">
        </div>
        <div class="info">
            <p class="brand"><?php echo e($product->brand); ?></p>
            <p class="name"><?php echo e($product->product_name); ?></p>
            <p class="price">$<?php echo e(number_format($product->price, 2)); ?></p>
        </div>
    </a>
</div>
<?php /**PATH C:\wamp64\www\Digital_Dialog old\resources\views/partials/product-card.blade.php ENDPATH**/ ?>