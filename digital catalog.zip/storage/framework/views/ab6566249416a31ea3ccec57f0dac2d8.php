<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Admin — Mood Set-up Studio'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        :root {
    --sidebar:   260px;  /* Add this line */
    --bg:        #f5f5f8;
    --bg:        #f5f5f8;
    --surface:   #ffffff;
    --card:      #ffffff;
    --border:    #9a9a9c;
    --accent:    #a60606;
    --accent2:   #ce3530;
    --accent3:   #004b4e;
    --text:      #111118;
    --muted:     #010110;
    --danger:    #e03355;
    --success:   #00a876;
}
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'DM Sans', sans-serif; background: var(--bg); color: var(--text); display: flex; min-height: 100vh; }
        h1,h2,h3,h4,h5 { font-family: 'Syne', sans-serif; }

        /* SIDEBAR */
        .sidebar {
            width: var(--sidebar); flex-shrink: 0;
            background: var(--surface);
            border-right: 1px solid var(--border);
            display: flex; flex-direction: column;
            position: fixed; height: 100vh; top: 0; left: 0;
            z-index: 50;
        }
        .sidebar-logo {
            padding: 1.5rem 1.25rem;
            border-bottom: 1px solid var(--border);
        }
        .sidebar-logo a {
            font-family: 'Syne', sans-serif; font-weight: 800; font-size: 1.2rem;
            color: var(--text); text-decoration: none;
        }
        .sidebar-logo a span { color: var(--accent2); }
        .sidebar-logo p { font-size: 0.72rem; color: var(--muted); margin-top: 0.1rem; }
        .sidebar-nav { padding: 1rem 0.75rem; flex: 1; overflow-y: auto; }
        .sidebar-nav p.nav-label {
            font-size: 0.68rem; text-transform: uppercase; letter-spacing: 0.1em;
            color: var(--muted); padding: 0.5rem 0.5rem 0.4rem; margin-top: 0.5rem;
        }
        .sidebar-nav a {
            display: flex; align-items: center; gap: 0.65rem;
            padding: 0.6rem 0.75rem; border-radius: 8px;
            color: var(--muted); text-decoration: none; font-size: 0.875rem;
            transition: all 0.15s; margin-bottom: 0.15rem;
        }
        .sidebar-nav a:hover { background: var(--card); color: var(--text); }
        .sidebar-nav a.active { background: rgba(242, 241, 249, 0.84); color: var(--accent); }
        .sidebar-nav svg { flex-shrink: 0; }
        .sidebar-footer {
            padding: 1rem 1.25rem;
            border-top: 1px solid var(--border);
            font-size: 0.8rem; color: var(--muted);
        }
        .sidebar-footer a { color: var(--danger); text-decoration: none; }

        /* MAIN */
        .main-wrap { margin-left: var(--sidebar); flex: 1; display: flex; flex-direction: column; min-height: 100vh; }
        .topbar {
            height: 60px; border-bottom: 1px solid var(--border);
            padding: 0 2rem;
            display: flex; align-items: center; justify-content: space-between;
            background: rgba(241, 241, 245, 0.8); backdrop-filter: blur(12px);
            position: sticky; top: 0; z-index: 40;
        }
        .topbar h2 { font-size: 1rem; font-weight: 700; }
        .topbar-user { font-size: 0.85rem; color: var(--muted); }
        .page-content { padding: 2rem; flex: 1; }

        /* CARDS & TABLES */
        .card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; overflow: hidden; }
        .card-body { padding: 1.5rem; }
        .card-header { padding: 1rem 1.5rem; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; }
        .card-header h3 { font-size: 1rem; font-weight: 700; }

        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.85rem 1rem; text-align: left; border-bottom: 1px solid var(--border); font-size: 0.875rem; }
        th { font-size: 0.72rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.06em; font-weight: 500; background: var(--surface); }
        tr:last-child td { border-bottom: none; }
        tbody tr:hover { background: rgba(255,255,255,0.02); }

        /* STAT CARDS */
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 2rem; }
        .stat-card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 1.25rem; }
        .stat-card .label { font-size: 0.75rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.07em; margin-bottom: 0.5rem; }
        .stat-card .value { font-family: 'Syne', sans-serif; font-size: 2rem; font-weight: 800; }
        .stat-card .sub   { font-size: 0.78rem; color: var(--muted); margin-top: 0.3rem; }

        /* FORM */
        .form-group { margin-bottom: 1.25rem; }
        .form-group label { display: block; font-size: 0.82rem; color: var(--muted); margin-bottom: 0.4rem; }
        .form-control {
            width: 100%; padding: 0.65rem 0.9rem;
            background: var(--surface); border: 1px solid var(--border);
            border-radius: 8px; color: var(--text); font-size: 0.9rem;
            outline: none; transition: border-color 0.2s;
            font-family: 'DM Sans', sans-serif;
        }
        .form-control:focus { border-color: var(--accent); }
        textarea.form-control { resize: vertical; min-height: 100px; }
        select.form-control option { background: var(--surface); }
        .form-error { color: var(--danger); font-size: 0.78rem; margin-top: 0.3rem; }

        /* BUTTONS */
        .btn { display: inline-flex; align-items: center; gap: 0.4rem; padding: 0.6rem 1.2rem; border-radius: 8px; border: none; font-size: 0.875rem; font-weight: 500; cursor: pointer; text-decoration: none; transition: all 0.2s; font-family: 'DM Sans', sans-serif; }
        .btn-primary { background: var(--accent); color: #fff; }
        .btn-outline  { background: transparent; border: 1px solid var(--border); color: var(--text); }
        .btn-outline:hover { border-color: var(--accent); color: var(--accent); }
        .btn-danger   { background: var(--danger); color: #fff; }
        .btn-sm       { padding: 0.3rem 0.7rem; font-size: 0.78rem; }
        .btn-primary:hover, .btn-danger:hover { opacity: 0.85; }

        /* CHIPS */
        .chip { display: inline-flex; align-items: center; padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.72rem; font-weight: 600; }
        .chip-green  { background: rgba(0,196,140,0.12); color: var(--success); }
        .chip-red    { background: rgba(255,79,109,0.12); color: var(--danger);  }

        /* FLASH */
        .flash { padding: 0.8rem 1.2rem; border-radius: 8px; margin-bottom: 1.5rem; font-size: 0.875rem; }
        .flash.success { background: rgba(0,196,140,0.1); border: 1px solid var(--success); color: var(--success); }
        .flash.error   { background: rgba(255,79,109,0.1); border: 1px solid var(--danger);  color: var(--danger);  }

        /* GRID */
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>


<aside class="sidebar">
    <div class="sidebar-logo">
        <a href="<?php echo e(route('admin.dashboard')); ?>">Mood Set-up<span>Studio</span></a>
        <p>Admin Panel</p>
    </div>
    <nav class="sidebar-nav">
        <p class="nav-label">Overview</p>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
            Dashboard
        </a>

        <p class="nav-label">Catalog</p>
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="<?php echo e(request()->routeIs('admin.categories.*') ? 'active' : ''); ?>">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"/></svg>
            Categories
        </a>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="<?php echo e(request()->routeIs('admin.products.*') ? 'active' : ''); ?>">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
            Products
        </a>

        <p class="nav-label">Store</p>
        <a href="<?php echo e(route('home')); ?>" target="_blank">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
            View Store
        </a>
    </nav>
    <div class="sidebar-footer">
        <p style="margin-bottom:0.4rem;"><?php echo e(auth()->user()->name ?? 'Admin'); ?></p>
        <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline;">
            <?php echo csrf_field(); ?>
            <button type="submit" style="background:none;border:none;color:var(--danger);cursor:pointer;font-size:0.8rem;padding:0;">Logout</button>
        </form>
    </div>
</aside>


<div class="main-wrap">
    <div class="topbar">
        <h2><?php echo $__env->yieldContent('topbar-title', 'Dashboard'); ?></h2>
        <span class="topbar-user"><?php echo e(auth()->user()->name ?? 'Admin'); ?></span>
    </div>
    <div class="page-content">
        <?php if(session('success')): ?>
            <div class="flash success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="flash error"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\Digital_Dialog\resources\views/layouts/admin.blade.php ENDPATH**/ ?>