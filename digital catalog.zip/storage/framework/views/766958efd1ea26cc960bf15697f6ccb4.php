<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Mood Set-up Studio — Digital Catalog'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        :root {
    --bg:        #faf2f2;
    --surface:   #ffffff;
    --card:      #ffffff;
    --border:    #e2e2ea;
    --accent:    #a60606;
    --accent2:   #ce3530;
    --accent3:   #004b4e;
    --text:      #111118;
    --muted:     #040404;
    --danger:    #e03355;
    --success:   #00a876;
}
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            line-height: 1.6;
        }
        h1,h2,h3,h4,h5 { font-family: 'Syne', sans-serif; }

        /* NAV */
        nav {
            position: sticky; top: 0; z-index: 100;
            rgba(245,245,248,0.9)
            backdrop-filter: blur(16px);
            border-bottom: 1px solid var(--border);
            padding: 0 2rem;
        }
        .nav-inner {
            max-width: 1280px; margin: auto;
            display: flex; align-items: center; gap: 2rem;
            height: 64px;
        }
        .nav-logo {
            font-family: 'Syne', sans-serif;
            font-weight: 800; font-size: 1.3rem;
            color: var(--accent3); text-decoration: none;
            display: flex; align-items: center; gap: 0.5rem;
        }
        .nav-logo span { color: var(--accent2); }
        .nav-search {
            flex: 1; position: relative; max-width: 480px;
        }
        .nav-search input {
            width: 100%; padding: 0.5rem 1rem 0.5rem 2.6rem;
            background: var(--surface); border: 1px solid var(--border);
            border-radius: 8px; color: var(--text); font-size: 0.9rem;
            outline: none; transition: border-color 0.2s;
        }
        .nav-search input:focus { border-color: var(--accent); }
        .nav-search svg {
            position: absolute; left: 0.7rem; top: 50%; transform: translateY(-50%);
            color: var(--muted); pointer-events: none;
        }
        .nav-links { margin-left: auto; display: flex; align-items: center; gap: 1rem; }
        .nav-links a {
            color: var(--muted); text-decoration: none; font-size: 0.9rem;
            transition: color 0.2s; padding: 0.3rem 0.6rem; border-radius: 6px;
        }
        .nav-links a:hover, .nav-links a.active { color: var(--text); }
        .btn-accent {
            background: var(--accent); color: #fff; border: none; border-radius: 8px;
            padding: 0.5rem 1.2rem; font-size: 0.875rem; font-weight: 500;
            cursor: pointer; text-decoration: none; transition: opacity 0.2s, transform 0.15s;
            font-family: 'DM Sans', sans-serif;
        }
        .btn-accent:hover { opacity: 0.88; transform: translateY(-1px); }

        /* MAIN */
        .container { max-width: 1280px; margin: auto; padding: 0 2rem; }
        main { padding: 2.5rem 0 4rem; }

        /* FLASH */
        .flash {
            padding: 0.8rem 1.2rem; border-radius: 8px; margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }
        .flash.success { background: rgba(0,196,140,0.12); border: 1px solid var(--success); color: var(--success); }
        .flash.error   { background: rgba(255,79,109,0.12); border: 1px solid var(--danger);  color: var(--danger);  }

        /* CARDS */
        .card {
            background: var(--card); border: 1px solid var(--border); border-radius: 14px;
            overflow: hidden; transition: border-color 0.2s, transform 0.2s;
        }
        .card:hover { border-color: var(--accent); transform: translateY(-3px); }

        /* PRODUCT GRID */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 1.5rem;
        }
        .product-card { position: relative; cursor: pointer; }
        .product-card .img-wrap {
            aspect-ratio: 1; overflow: hidden;
            background: var(--surface);
        }
        .product-card img {
            width: 100%; height: 100%; object-fit: cover;
            transition: transform 0.4s ease;
        }
        .product-card:hover img { transform: scale(1.06); }
        .product-card .info { padding: 1rem; }
        .product-card .brand { font-size: 0.75rem; color: var(--accent2); text-transform: uppercase; letter-spacing: 0.08em; }
        .product-card .name { font-family: 'Syne', sans-serif; font-weight: 600; font-size: 1rem; margin: 0.2rem 0 0.4rem; line-height: 1.3; }
        .product-card .price { font-size: 1.1rem; font-weight: 700; color: var(--accent); }
        .product-card .badge {
            position: absolute; top: 0.75rem; left: 0.75rem;
            background: var(--danger); color: #fff;
            font-size: 0.7rem; font-weight: 600; padding: 0.2rem 0.5rem;
            border-radius: 4px; text-transform: uppercase;
        }
        .badge-available { background: var(--success) !important; }

        /* BUTTONS */
        .btn {
            display: inline-flex; align-items: center; gap: 0.4rem;
            padding: 0.6rem 1.2rem; border-radius: 8px; border: none;
            font-size: 0.875rem; font-weight: 500; cursor: pointer;
            text-decoration: none; transition: all 0.2s;
            font-family: 'DM Sans', sans-serif;
        }
        .btn-primary  { background: var(--accent);  color: #fff; }
        .btn-outline  { background: transparent; border: 1px solid var(--border); color: var(--text); }
        .btn-outline:hover { border-color: var(--accent); color: var(--accent); }
        .btn-danger   { background: var(--danger);  color: #fff; }
        .btn-sm       { padding: 0.35rem 0.8rem; font-size: 0.8rem; }
        .btn-primary:hover { opacity: 0.88; }
        .btn-danger:hover  { opacity: 0.88; }

        /* FORM */
        .form-group { margin-bottom: 1.25rem; }
        .form-group label { display: block; font-size: 0.85rem; color: var(--muted); margin-bottom: 0.4rem; }
        .form-control {
            width: 100%; padding: 0.65rem 0.9rem;
            background: var(--surface); border: 1px solid var(--border);
            border-radius: 8px; color: var(--text); font-size: 0.9rem;
            outline: none; transition: border-color 0.2s;
            font-family: 'DM Sans', sans-serif;
        }
        .form-control:focus { border-color: var(--accent); }
        textarea.form-control { resize: vertical; min-height: 100px; }
        select.form-control option { background: var(--surface); }
        .form-error { color: var(--danger); font-size: 0.8rem; margin-top: 0.3rem; }

        /* TABLE */
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.85rem 1rem; text-align: left; border-bottom: 1px solid var(--border); }
        th { font-size: 0.78rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.06em; font-weight: 500; }
        tr:last-child td { border-bottom: none; }
        tbody tr:hover { background: var(--surface); }

        /* PAGE SECTION */
        .page-header { margin-bottom: 2rem; }
        .page-header h1 { font-size: 1.8rem; font-weight: 800; }
        .page-header p { color: var(--muted); margin-top: 0.3rem; }

        /* FOOTER */
        footer {
            border-top: 1px solid var(--border);
            padding: 2rem;
            text-align: center;
            color: var(--muted);
            font-size: 0.85rem;
        }

        /* CHIPS / TAGS */
        .chip {
            display: inline-flex; align-items: center;
            padding: 0.25rem 0.65rem; border-radius: 20px;
            font-size: 0.75rem; font-weight: 600;
        }
        .chip-green  { background: rgba(0,196,140,0.12); color: var(--success); }
        .chip-red    { background: rgba(255,79,109,0.12); color: var(--danger);  }
        .chip-purple { background: rgba(108,99,255,0.12); color: var(--accent);  }

        /* COMPARE CHECKBOX */
        .compare-check {
            position: absolute; top: 0.75rem; right: 0.75rem;
            background: rgba(160, 13, 13, 0.81); border: 1px solid var(--border);
            border-radius: 6px; padding: 0.3rem 0.5rem;
            font-size: 0.72rem; color: #fff; cursor: pointer;
            display: flex; align-items: center; gap: 0.3rem;
            backdrop-filter: blur(4px);
            transition: all 0.2s;
        }
        .compare-check:hover, .compare-check.active {
            border-color: var(--accent2); color: var(--accent2);
        }
        .compare-bar {
            position: fixed; bottom: 1.5rem; left: 50%; transform: translateX(-50%);
            background: var(--card); border: 1px solid var(--accent);
            border-radius: 12px; padding: 0.75rem 1.5rem;
            display: flex; align-items: center; gap: 1rem;
            box-shadow: 0 8px 32px rgba(101, 100, 120, 0.2);
            z-index: 200; animation: slideUp 0.3s ease;
        }
        @keyframes slideUp { from { transform: translateX(-50%) translateY(20px); opacity:0; } }

        @media (max-width: 768px) {
            .nav-search { display: none; }
            .product-grid { grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 1rem; }
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<nav>
    <div class="nav-inner">
        <a href="<?php echo e(route('home')); ?>" class="nav-logo">
           Mood Set-up<span>Studio</span>
        </a>
        <form class="nav-search" action="<?php echo e(route('search')); ?>" method="GET">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <input type="text" name="q" placeholder="Search products, brands…" value="<?php echo e(request('q')); ?>">
        </form>
        <div class="nav-links">
            <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Home</a>
            <a href="<?php echo e(route('search')); ?>" class="<?php echo e(request()->routeIs('search') ? 'active' : ''); ?>">Browse</a>
            <a href="<?php echo e(route('about')); ?>" class="<?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">About</a>
            <a href="<?php echo e(route('faq')); ?>" class="<?php echo e(request()->routeIs('faq') ? 'active' : ''); ?>">FAQ</a>

            <?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->is_admin == 1): ?>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-accent">Admin Panel</a>
    <?php endif; ?>
    
    <!-- Show a logout button too so you can switch accounts -->
    <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline;">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-outline btn-sm">Logout</button>
    </form>
<?php else: ?>
    <a href="<?php echo e(route('login')); ?>" class="btn btn-outline btn-sm">Login</a>
<?php endif; ?>
        </div>
    </div>
</nav>

<div class="container">
    <main>
        <?php if(session('success')): ?>
            <div class="flash success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="flash error"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>

<footer>
    <p>Mood Set-up Studio Digital Catalog &copy; <?php echo e(date('Y')); ?> — Powered by Laravel</p>
</footer>

<script>
// Compare feature
const compareItems = JSON.parse(localStorage.getItem('compare') || '[]');
let compareBar;

function toggleCompare(id, name) {
    const idx = compareItems.indexOf(id);
    if (idx > -1) {
        compareItems.splice(idx, 1);
    } else {
        if (compareItems.length >= 3) {
            alert('You can compare up to 3 products.');
            return;
        }
        compareItems.push(id);
    }
    localStorage.setItem('compare', JSON.stringify(compareItems));
    updateCompareUI();
}

function updateCompareUI() {
    document.querySelectorAll('.compare-check').forEach(el => {
        const id = el.dataset.id;
        el.classList.toggle('active', compareItems.includes(id));
    });
    if (compareItems.length > 0) {
        if (!compareBar) {
            compareBar = document.createElement('div');
            compareBar.className = 'compare-bar';
            document.body.appendChild(compareBar);
        }
        compareBar.innerHTML = `
            <span style="font-size:0.85rem;color:var(--muted)">${compareItems.length} selected</span>
            <a href="/compare?ids=${compareItems.join(',')}" class="btn btn-primary btn-sm">Compare Now</a>
            <button onclick="clearCompare()" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:1.1rem;">✕</button>
        `;
    } else if (compareBar) {
        compareBar.remove(); compareBar = null;
    }
}

function clearCompare() {
    compareItems.length = 0;
    localStorage.setItem('compare', JSON.stringify(compareItems));
    updateCompareUI();
}

document.addEventListener('DOMContentLoaded', updateCompareUI);
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\Digital_Dialog old\resources\views/layouts/app.blade.php ENDPATH**/ ?>