<?php $__env->startSection('title', 'Categories — Admin'); ?>
<?php $__env->startSection('topbar-title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>




<div class="card" style="margin-bottom: 1.5rem; padding: 1rem;">
    <form action="<?php echo e(route('admin.categories.index')); ?>" method="GET" style="display: flex; gap: 1rem; align-items: flex-end;">
        <div style="flex: 1;">
            <label style="font-size: 0.75rem; color: var(--muted); margin-bottom: 0.4rem; display: block;">Search Category Name</label>
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="e.g. Adapters, Keyboards...">
        </div>
        <button type="submit" class="btn btn-primary">Search</button>
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline">Reset</a>
    </form>
</div>

<div class="card">

<div class="card">
    <div class="card-header">
        <h3>All Categories</h3>
        <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary btn-sm">+ New Category</a>
    </div>
    <table>
        <thead>
            <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Products</th>
                <th>Created</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php if($cat->category_image): ?>
                        <img src="<?php echo e(asset('storage/'.$cat->category_image)); ?>" style="width:44px;height:44px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">
                    <?php else: ?>
                        <div style="width:44px;height:44px;background:var(--surface);border-radius:8px;border:1px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--muted);">—</div>
                    <?php endif; ?>
                </td>
                <td style="font-weight:600;"><?php echo e($cat->category_name); ?></td>
                <td><span class="chip chip-green"><?php echo e($cat->products_count); ?></span></td>
                <td style="color:var(--muted);"><?php echo e($cat->created_at->format('M d, Y')); ?></td>
                <td>
                    <div style="display:flex;gap:0.5rem;">
                        <a href="<?php echo e(route('admin.categories.edit', $cat)); ?>" class="btn btn-outline btn-sm">Edit</a>
                        <form method="POST" action="<?php echo e(route('admin.categories.destroy', $cat)); ?>" onsubmit="return confirm('Delete this category?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:2.5rem;">No categories yet. <a href="<?php echo e(route('admin.categories.create')); ?>" style="color:var(--accent);">Add one</a>.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Dialog\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>