<?php $__env->startSection('title', 'Dashboard — Admin'); ?>
<?php $__env->startSection('topbar-title', 'Dashboard'); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* ── PROGRESS BARS ── */
.progress-wrap { margin-bottom: 1.35rem; }
.progress-wrap:last-child { margin-bottom: 0; }
.progress-meta {
    display: flex; justify-content: space-between; align-items: baseline;
    font-size: 0.83rem; margin-bottom: 0.4rem;
}
.progress-meta span { text-transform: capitalize; font-weight: 500; color: var(--ink); }
.progress-meta small { color: var(--ink-2); font-size: 0.75rem; }
.progress-track {
    background: var(--ghost); border-radius: 4px; height: 7px; overflow: hidden;
}
.progress-fill {
    height: 100%; border-radius: 4px;
    transition: width 0.7s cubic-bezier(.25,.8,.25,1);
}

/* ── BAR CHART ── */
.bar-chart {
    display: flex; align-items: flex-end; gap: 0.6rem;
    height: 140px; padding-bottom: 0;
}
.bar-col {
    flex: 1; display: flex; flex-direction: column; align-items: center; gap: 0.35rem;
}
.bar-val { font-size: 0.7rem; color: var(--ink-2); font-weight: 600; }
.bar-fill {
    width: 100%; border-radius: 6px 6px 0 0;
    background: var(--teal);
    transition: height 0.6s cubic-bezier(.25,.8,.25,1);
    min-height: 6px;
}
.bar-fill.accent { background: var(--red); }
.bar-date { font-size: 0.65rem; color: var(--ink-2); white-space: nowrap; }

/* ── ACTIVITY ITEM ── */
.activity-dot {
    width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; margin-top: 4px;
}

/* ── TABLE CHIP ── */
.rank-num {
    width: 24px; height: 24px; border-radius: 6px;
    background: var(--ghost); display: inline-flex;
    align-items: center; justify-content: center;
    font-size: 0.72rem; font-weight: 700; color: var(--ink-2);
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<div class="stats-grid">
    <div class="stat-card teal">
        <p class="label">Total Products</p>
        <p class="value" style="color:var(--teal);"><?php echo e($totalProducts); ?></p>
        <p class="sub">Across all categories</p>
    </div>
    <div class="stat-card red">
        <p class="label">Categories</p>
        <p class="value" style="color:var(--red);"><?php echo e($totalCategories); ?></p>
        <p class="sub">Active categories</p>
    </div>
    <div class="stat-card danger">
        <p class="label">Out of Stock</p>
        <p class="value" style="color:var(--danger);"><?php echo e($outOfStock); ?></p>
        <p class="sub">Need restocking</p>
    </div>
    <div class="stat-card warn">
        <p class="label">Total Interactions</p>
        <p class="value" style="color:var(--warn);"><?php echo e($totalInteractions); ?></p>
        <p class="sub">Views, searches, compares</p>
    </div>
</div>


<div class="grid-2" style="margin-bottom:1.5rem;">

    
    <div class="card">
        <div class="card-header">
            <h3>Product Activity</h3>
            <a href="<?php echo e(route('admin.interactions')); ?>" class="btn btn-outline btn-sm">Full Report →</a>
        </div>
        <table>
            <thead>
                <tr>
                    <th style="width:32px;">#</th>
                    <th>Product</th>
                    <th style="text-align:center;">Views</th>
                    <th style="text-align:center;">Search</th>
                    <th style="text-align:center;">Compare</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><span class="rank-num"><?php echo e($i + 1); ?></span></td>
                    <td style="font-weight:500;font-size:0.85rem;max-width:160px;">
                        <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                            <?php echo e($item->product->product_name ?? 'Deleted Product'); ?>

                        </div>
                    </td>
                    <td style="text-align:center;">
                        <span class="chip chip-teal"><?php echo e($item->views_count); ?></span>
                    </td>
                    <td style="text-align:center;">
                        <span class="chip chip-red"><?php echo e($item->search_count); ?></span>
                    </td>
                    <td style="text-align:center;">
                        <span class="chip chip-amber"><?php echo e($item->compare_count); ?></span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" style="color:var(--ink-2);text-align:center;padding:2.5rem;font-size:0.85rem;">
                        No interaction data yet.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3>Interactions by Type</h3>
        </div>
        <div class="card-body">
            <?php
                $typeColors = [
                    'view'    => 'var(--teal)',
                    'search'  => 'var(--red)',
                    'compare' => 'var(--warn)',
                ];
            ?>

            <?php $__empty_1 = true; $__currentLoopData = $interactionsByType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $total = $interactionsByType->sum();
                    $pct   = $total > 0 ? round($count / $total * 100) : 0;
                    $color = $typeColors[$type] ?? 'var(--teal)';
                ?>
                <div class="progress-wrap">
                    <div class="progress-meta">
                        <span><?php echo e(ucfirst($type)); ?></span>
                        <small><?php echo e(number_format($count)); ?> &nbsp;·&nbsp; <?php echo e($pct); ?>%</small>
                    </div>
                    <div class="progress-track">
                        <div class="progress-fill" style="width:<?php echo e($pct); ?>%;background:<?php echo e($color); ?>;"></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p style="color:var(--ink-2);text-align:center;padding:2.5rem 0;font-size:0.85rem;">
                    No interactions recorded yet.
                </p>
            <?php endif; ?>

            <?php if($interactionsByType->isNotEmpty()): ?>
            <div style="margin-top:1.5rem;padding-top:1.25rem;border-top:1px solid var(--line);display:flex;gap:1.5rem;">
                <?php $__currentLoopData = $typeColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="display:flex;align-items:center;gap:0.4rem;">
                    <div style="width:8px;height:8px;border-radius:50%;background:<?php echo e($color); ?>;"></div>
                    <span style="font-size:0.75rem;color:var(--ink-2);text-transform:capitalize;"><?php echo e($label); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="card">
    <div class="card-header">
        <h3>Daily Interactions — Last 7 Days</h3>
        <span style="font-size:0.78rem;color:var(--ink-2);"><?php echo e(now()->subDays(6)->format('M d')); ?> – <?php echo e(now()->format('M d, Y')); ?></span>
    </div>
    <div class="card-body">
        <?php if($dailyInteractions->isEmpty()): ?>
            <p style="color:var(--ink-2);text-align:center;padding:3rem 0;font-size:0.875rem;">
                No data for the past 7 days.
            </p>
        <?php else: ?>
            <?php $maxCount = $dailyInteractions->max('count') ?: 1; ?>
            <div class="bar-chart">
                <?php $__currentLoopData = $dailyInteractions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $height  = max(8, round(($day->count / $maxCount) * 110));
                        $isToday = \Carbon\Carbon::parse($day->date)->isToday();
                    ?>
                    <div class="bar-col">
                        <span class="bar-val"><?php echo e($day->count); ?></span>
                        <div class="bar-fill <?php echo e($isToday ? 'accent' : ''); ?>" style="height:<?php echo e($height); ?>px;"></div>
                        <span class="bar-date"><?php echo e(\Carbon\Carbon::parse($day->date)->format('M d')); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div style="margin-top:1rem;display:flex;gap:1rem;align-items:center;">
                <div style="display:flex;align-items:center;gap:0.4rem;">
                    <div style="width:10px;height:10px;border-radius:3px;background:var(--teal);"></div>
                    <span style="font-size:0.72rem;color:var(--ink-2);">Previous days</span>
                </div>
                <div style="display:flex;align-items:center;gap:0.4rem;">
                    <div style="width:10px;height:10px;border-radius:3px;background:var(--red);"></div>
                    <span style="font-size:0.72rem;color:var(--ink-2);">Today</span>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Catalog\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>