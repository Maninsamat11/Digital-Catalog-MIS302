<?php $__env->startSection('title', 'Search — TechVault'); ?>

<?php $__env->startSection('content'); ?>

<div style="display:flex;gap:2rem;align-items:flex-start;">

    
    <aside style="width:220px;flex-shrink:0;">
        <div class="card" style="padding:1.25rem;">
            <p style="font-family:'Syne',sans-serif;font-weight:700;margin-bottom:1rem;font-size:0.95rem;">Filter by Category</p>
            <form action="<?php echo e(route('search')); ?>" method="GET" id="filterForm">
                <input type="hidden" name="q" value="<?php echo e($query); ?>">
                <div style="display:flex;flex-direction:column;gap:0.5rem;">
                    <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;font-size:0.875rem;color:var(--muted);">
                        <input type="radio" name="category" value="" <?php echo e(!$categoryId ? 'checked' : ''); ?> onchange="document.getElementById('filterForm').submit()">
                        All Categories
                    </label>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;font-size:0.875rem;color:<?php echo e($categoryId == $cat->id ? 'var(--text)' : 'var(--muted)'); ?>;">
                        <input type="radio" name="category" value="<?php echo e($cat->id); ?>" <?php echo e($categoryId == $cat->id ? 'checked' : ''); ?> onchange="document.getElementById('filterForm').submit()">
                        <?php echo e($cat->category_name); ?>

                    </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </form>
        </div>
    </aside>

    
    <div style="flex:1;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;">
            <div>
                <h1 style="font-size:1.4rem;font-weight:800;">
                    <?php echo e($query ? "Results for \"$query\"" : 'All Products'); ?>

                </h1>
                <p style="color:var(--muted);font-size:0.875rem;margin-top:0.2rem;"><?php echo e($products->count()); ?> product(s) found</p>
            </div>
        </div>

        <?php if($products->isEmpty()): ?>
            <div style="text-align:center;padding:4rem 0;">
                <p style="font-size:3rem;margin-bottom:1rem;">🔍</p>
                <p style="color:var(--muted);">No products found. Try a different search term.</p>
                <a href="<?php echo e(route('search')); ?>" class="btn btn-outline" style="margin-top:1rem;">Browse All</a>
            </div>
        <?php else: ?>
            <div class="product-grid">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Digital_Catalog\resources\views/customer/search.blade.php ENDPATH**/ ?>