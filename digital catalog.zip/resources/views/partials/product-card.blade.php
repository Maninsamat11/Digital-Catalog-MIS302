<div class="card product-card">
    @if($product->status === 'out_of_stock')
        <span class="badge-oos">Out of Stock</span>
    @endif

    <button
        class="compare-check"
        data-id="{{ $product->id }}"
        onclick="toggleCompare('{{ $product->id }}', '{{ addslashes($product->product_name) }}')"
        title="Add to compare"
    >
        <svg width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path d="M18 20V10M12 20V4M6 20v-6"/>
        </svg>
        Compare
    </button>

    <a href="{{ route('product.show', $product) }}" style="text-decoration:none;color:inherit;display:block;">
        <div class="img-wrap">
            <img
                src="{{ asset('storage/'.$product->product_image) }}"
                alt="{{ $product->product_name }}"
                loading="lazy"
            >
        </div>
        <div class="info">
            <p class="brand">{{ $product->brand }}</p>
            <p class="name">{{ $product->product_name }}</p>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:0.5rem;">
                <p class="price">${{ number_format($product->price, 2) }}</p>
                @if($product->status !== 'out_of_stock')
                    <span class="chip chip-teal">Available</span>
                @endif
            </div>
        </div>
    </a>
</div>