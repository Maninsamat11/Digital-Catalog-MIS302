@extends('layouts.app')

@section('title', 'Search — TechVault')

@section('content')

<div style="display:flex;gap:2rem;align-items:flex-start;">

    {{-- SIDEBAR FILTERS --}}
    <aside style="width:220px;flex-shrink:0;">
        <div class="card" style="padding:1.25rem;">
            <p style="font-family:'Syne',sans-serif;font-weight:700;margin-bottom:1rem;font-size:0.95rem;">Filter by Category</p>
            <form action="{{ route('search') }}" method="GET" id="filterForm">
                <input type="hidden" name="q" value="{{ $query }}">
                <div style="display:flex;flex-direction:column;gap:0.5rem;">
                    <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;font-size:0.875rem;color:var(--muted);">
                        <input type="radio" name="category" value="" {{ !$categoryId ? 'checked' : '' }} onchange="document.getElementById('filterForm').submit()">
                        All Categories
                    </label>
                    @foreach($categories as $cat)
                    <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;font-size:0.875rem;color:{{ $categoryId == $cat->id ? 'var(--text)' : 'var(--muted)' }};">
                        <input type="radio" name="category" value="{{ $cat->id }}" {{ $categoryId == $cat->id ? 'checked' : '' }} onchange="document.getElementById('filterForm').submit()">
                        {{ $cat->category_name }}
                    </label>
                    @endforeach
                </div>
            </form>
        </div>
    </aside>

    {{-- RESULTS --}}
    <div style="flex:1;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;">
            <div>
                <h1 style="font-size:1.4rem;font-weight:800;">
                    {{ $query ? "Results for \"$query\"" : 'All Products' }}
                </h1>
                <p style="color:var(--muted);font-size:0.875rem;margin-top:0.2rem;">{{ $products->count() }} product(s) found</p>
            </div>
        </div>

        @if($products->isEmpty())
            <div style="text-align:center;padding:4rem 0;">
                <p style="font-size:3rem;margin-bottom:1rem;">🔍</p>
                <p style="color:var(--muted);">No products found. Try a different search term.</p>
                <a href="{{ route('search') }}" class="btn btn-outline" style="margin-top:1rem;">Browse All</a>
            </div>
        @else
            <div class="product-grid">
                @foreach($products as $product)
                    @include('partials.product-card', ['product' => $product])
                @endforeach
            </div>
        @endif
    </div>
</div>

@endsection
