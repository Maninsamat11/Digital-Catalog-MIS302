@extends('layouts.app')

@section('title', $product->product_name . ' — TechVault')

@section('content')

{{-- Breadcrumb --}}
<div style="margin-bottom:2rem;font-size:0.85rem;color:var(--muted);">
    <a href="{{ route('home') }}" style="color:var(--muted);text-decoration:none;">Home</a>
    <span style="margin:0 0.5rem;">/</span>
    <a href="{{ route('category.show', $product->category) }}" style="color:var(--muted);text-decoration:none;">{{ $product->category->category_name }}</a>
    <span style="margin:0 0.5rem;">/</span>
    <span style="color:var(--text);">{{ $product->product_name }}</span>
</div>

{{-- Main Product Section --}}
<div style="display:grid;grid-template-columns:1fr 1fr;gap:3rem;margin-bottom:4rem;">

    {{-- Image --}}
    <div>
        <div style="background:var(--surface);border:1px solid var(--border);border-radius:16px;overflow:hidden;aspect-ratio:1;">
            <img src="{{ asset('storage/'.$product->product_image) }}" alt="{{ $product->product_name }}"
                 style="width:100%;height:100%;object-fit:cover;">
        </div>
    </div>

    {{-- Info --}}
    <div>
        <p style="font-size:0.78rem;color:var(--accent2);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.4rem;">{{ $product->brand }}</p>
        <h1 style="font-size:2rem;font-weight:800;line-height:1.2;margin-bottom:1rem;">{{ $product->product_name }}</h1>

        <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;">
            <span style="font-size:2.2rem;font-weight:800;color:var(--accent);">${{ number_format($product->price, 2) }}</span>
            @if($product->status === 'available')
                <span class="chip chip-green">In Stock ({{ $product->stock_quantity }})</span>
            @else
                <span class="chip chip-red">Out of Stock</span>
            @endif
        </div>

        <div style="border-top:1px solid var(--border);padding-top:1.25rem;margin-bottom:1.5rem;">
            <p style="color:var(--muted);line-height:1.7;">{{ $product->description }}</p>
        </div>

        {{-- Specs Table --}}
        <div class="card" style="margin-bottom:1.5rem;">
            <table>
                <tbody>
                    <tr>
                        <td style="color:var(--muted);width:40%;font-size:0.875rem;">Category</td>
                        <td style="font-size:0.875rem;">{{ $product->category->category_name }}</td>
                    </tr>
                    <tr>
                        <td style="color:var(--muted);font-size:0.875rem;">Brand</td>
                        <td style="font-size:0.875rem;">{{ $product->brand }}</td>
                    </tr>
                    <tr>
                        <td style="color:var(--muted);font-size:0.875rem;">Stock</td>
                        <td style="font-size:0.875rem;">{{ $product->stock_quantity }} units</td>
                    </tr>
                    <tr>
                        <td style="color:var(--muted);font-size:0.875rem;">Status</td>
                        <td>
                            @if($product->status === 'available')
                                <span class="chip chip-green" style="font-size:0.75rem;">Available</span>
                            @else
                                <span class="chip chip-red" style="font-size:0.75rem;">Out of Stock</span>
                            @endif
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        {{-- Actions --}}
        <div style="display:flex;gap:0.75rem;">
            <button class="btn btn-primary" onclick="toggleCompare('{{ $product->id }}', '{{ addslashes($product->product_name) }}')">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-6"/></svg>
                Add to Compare
            </button>
            <a href="{{ route('search', ['category' => $product->category_id]) }}" class="btn btn-outline">
                Browse Similar
            </a>
        </div>
    </div>
</div>

{{-- Related Products --}}
@if($related->isNotEmpty())
<section>
    <h2 style="font-size:1.3rem;font-weight:700;margin-bottom:1.25rem;">Related Products</h2>
    <div class="product-grid">
        @foreach($related as $relProduct)
            @include('partials.product-card', ['product' => $relProduct])
        @endforeach
    </div>
</section>
@endif

@endsection
