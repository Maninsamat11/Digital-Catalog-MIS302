@extends('layouts.app')

@section('title', 'Mood Set-up Studio — Digital Catalog')

@push('styles')
<style>
/* ── HERO ── */
.hero {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0;
    min-height: 500px;
    overflow: hidden;
    border-radius: var(--radius-lg);
    margin: 2.5rem 0 3rem;
    border: 0.5px solid rgba(0,0,0,0.1);
    box-shadow: 0 2px 20px rgba(0,0,0,0.06), 0 0 0 0.5px rgba(0,0,0,0.04);
}
.hero-left {
    background: linear-gradient(145deg, #004b4e 0%, #003538 100%);
    padding: 3.5rem 3rem;
    display: flex;
    flex-direction: column;
    justify-content: center;
    position: relative;
    overflow: hidden;
}
.hero-left::before {
    content: '';
    position: absolute; top: -50px; right: -50px;
    width: 240px; height: 240px; border-radius: 50%;
    background: radial-gradient(circle, rgba(206,53,48,0.22) 0%, transparent 70%);
    pointer-events: none;
}
.hero-left::after {
    content: '';
    position: absolute; bottom: -70px; left: 20px;
    width: 180px; height: 180px; border-radius: 50%;
    background: rgba(255,255,255,0.04);
    pointer-events: none;
}
.hero-eyebrow {
    display: inline-flex; align-items: center; gap: 0.5rem;
    background: rgba(255,255,255,0.1);
    border: 0.5px solid rgba(255,255,255,0.2);
    color: rgba(255,255,255,0.7); border-radius: 20px;
    padding: 0.28rem 0.9rem; font-size: 0.7rem;
    font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em;
    margin-bottom: 1.4rem; width: fit-content;
}
.hero-eyebrow::before { content: '✦'; font-size: 0.6rem; }
.hero-h1 {
    font-size: clamp(2.2rem, 4vw, 3.4rem);
    font-weight: 700; line-height: 1.08;
    color: var(--white); margin-bottom: 1.1rem;
    letter-spacing: -0.5px;
}
.hero-h1 span { color: #ff6b68; display: block; }
.hero-sub {
    color: rgba(255,255,255,0.55);
    font-size: 0.975rem; max-width: 320px; line-height: 1.65;
    margin-bottom: 2rem;
}
.hero-actions { display: flex; gap: 0.65rem; flex-wrap: wrap; }

.hero-right {
    background: rgba(255,255,255,0.88);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    display: flex; flex-direction: column;
}
.hero-search-panel {
    padding: 2.25rem 2.25rem 1.75rem;
    border-left: 0.5px solid rgba(0,0,0,0.08);
    flex: 1; display: flex; flex-direction: column; justify-content: center;
}
.hero-search-panel h2 {
    font-size: 1.05rem; font-weight: 700; margin-bottom: 0.3rem;
    color: var(--teal); letter-spacing: -0.2px;
}
.hero-search-panel p { font-size: 0.83rem; color: #8e8e93; margin-bottom: 1.1rem; }
.hero-search-row { display: flex; gap: 0.5rem; }
.hero-search-row input {
    flex: 1; padding: 0.65rem 0.9rem;
    background: rgba(120,120,128,0.1);
    border: 0.5px solid rgba(0,0,0,0.1);
    border-radius: 10px; font-size: 0.875rem; color: var(--ink);
    outline: none; font-family: inherit;
    transition: border-color 0.2s, background 0.2s, box-shadow 0.2s;
}
.hero-search-row input:focus {
    border-color: var(--teal);
    background: var(--white);
    box-shadow: 0 0 0 3px rgba(0,75,78,0.08);
}

.hero-stats {
    display: grid; grid-template-columns: 1fr 1fr;
    border-top: 0.5px solid rgba(0,0,0,0.08);
    border-left: 0.5px solid rgba(0,0,0,0.08);
}
.hero-stat {
    padding: 1.25rem 1.5rem;
    border-right: 0.5px solid rgba(0,0,0,0.06);
    transition: background 0.2s;
}
.hero-stat:nth-child(3), .hero-stat:nth-child(4) {
    border-top: 0.5px solid rgba(0,0,0,0.06);
}
.hero-stat:hover { background: rgba(0,75,78,0.03); }
.hero-stat-num {
    font-size: 1.9rem; font-weight: 700; color: var(--teal);
    line-height: 1; letter-spacing: -0.5px;
}
.hero-stat-label { font-size: 0.72rem; color: #8e8e93; margin-top: 0.25rem; font-weight: 500; }

/* ── SECTION LABEL ── */
.section-label {
    display: flex; align-items: center; gap: 0.75rem;
    margin-bottom: 1.25rem;
}
.section-label h2 { font-size: 1.4rem; font-weight: 700; color: var(--ink); letter-spacing: -0.3px; }
.section-label a {
    margin-left: auto; font-size: 0.8rem; color: var(--red);
    text-decoration: none; font-weight: 600;
    display: flex; align-items: center; gap: 0.3rem;
    transition: gap 0.2s;
}
.section-label a:hover { gap: 0.55rem; }
.section-divider {
    width: 24px; height: 3px; border-radius: 2px; background: var(--red);
    margin-bottom: 1.25rem;
}

/* ── CATEGORY GRID ── */
.cat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 0.875rem;
    margin-bottom: 3.5rem;
}
.cat-card {
    background: rgba(255,255,255,0.8);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 0.5px solid rgba(0,0,0,0.08);
    border-radius: var(--radius-lg);
    padding: 1.4rem 1.1rem 1.1rem;
    text-align: center; text-decoration: none; color: inherit;
    display: flex; flex-direction: column; align-items: center;
    transition: transform 0.25s var(--spring), box-shadow 0.25s, border-color 0.25s;
    position: relative; overflow: hidden;
}
.cat-card::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 2.5px;
    background: var(--red);
    transform: scaleX(0); transform-origin: left;
    transition: transform 0.3s ease;
}
.cat-card:hover {
    border-color: rgba(0,75,78,0.18);
    box-shadow: 0 8px 24px rgba(0,75,78,0.1), 0 2px 6px rgba(0,0,0,0.05);
    transform: translateY(-5px) scale(1.01);
}
.cat-card:hover::before { transform: scaleX(1); }
.cat-icon {
    width: 52px; height: 52px; border-radius: 14px;
    background: rgba(0,75,78,0.08); margin-bottom: 0.85rem;
    display: flex; align-items: center; justify-content: center;
    overflow: hidden; transition: background 0.25s;
}
.cat-card:hover .cat-icon { background: rgba(206,53,48,0.08); }
.cat-icon img { width: 100%; height: 100%; object-fit: cover; border-radius: 14px; }
.cat-name {
    font-weight: 700; font-size: 0.875rem; color: var(--ink);
    line-height: 1.3; letter-spacing: -0.15px;
}
.cat-count { font-size: 0.7rem; color: #8e8e93; margin-top: 0.2rem; }

/* ── PRODUCT SECTION ── */
.products-section { margin-bottom: 3.5rem; }

/* ── PROMO BANNER ── */
.promo-banner {
    background: linear-gradient(135deg, #ce3530 0%, #a32420 100%);
    border-radius: var(--radius-lg);
    padding: 2.25rem 2.75rem;
    display: flex; align-items: center; justify-content: space-between;
    gap: 2rem; margin-bottom: 3.5rem;
    position: relative; overflow: hidden;
    border: 0.5px solid rgba(255,255,255,0.12);
    box-shadow: 0 4px 28px rgba(206,53,48,0.28), 0 1px 4px rgba(0,0,0,0.08);
}
.promo-banner::before {
    content: '';
    position: absolute; top: -40px; right: 220px;
    width: 180px; height: 180px; border-radius: 50%;
    background: rgba(255,255,255,0.07); pointer-events: none;
}
.promo-banner::after {
    content: '';
    position: absolute; bottom: -55px; right: -25px;
    width: 220px; height: 220px; border-radius: 50%;
    background: rgba(0,75,78,0.15); pointer-events: none;
}
.promo-text h3 {
    font-size: 1.5rem; font-weight: 700; color: var(--white);
    line-height: 1.2; margin-bottom: 0.4rem; letter-spacing: -0.3px;
}
.promo-text p { color: rgba(255,255,255,0.65); font-size: 0.875rem; }
.promo-cta {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 0.5px solid rgba(255,255,255,0.3);
    color: var(--white);
    padding: 0.68rem 1.6rem; border-radius: 20px;
    font-size: 0.875rem; font-weight: 700;
    text-decoration: none; font-family: inherit;
    white-space: nowrap; flex-shrink: 0;
    transition: background 0.2s, transform 0.2s;
    position: relative; z-index: 1;
}
.promo-cta:hover { background: rgba(255,255,255,0.25); transform: scale(1.03); }

@media (max-width: 900px) {
    .hero { grid-template-columns: 1fr; min-height: auto; }
    .hero-right { display: none; }
    .hero-left { padding: 2.75rem 1.75rem; }
    .promo-banner { flex-direction: column; text-align: center; padding: 1.75rem 1.5rem; }
    .cat-grid { grid-template-columns: repeat(auto-fill, minmax(135px, 1fr)); }
}
</style>
@endpush

@section('content')

{{-- HERO --}}
<section class="hero">
    <div class="hero-left">
        <div class="hero-eyebrow">In-Store Digital Catalog</div>
        <h1 class="hero-h1">
            Set The Mood.<br>
            <span>Build Your Setup.</span>
        </h1>
        <p class="hero-sub">Browse our full product range, compare specs, and find exactly what fits your space — all at your own pace.</p>
        <div class="hero-actions">
            <a href="{{ route('search') }}" class="btn btn-primary">Browse All Products</a>
            <a href="{{ route('about') }}" class="btn btn-outline" style="color:rgba(255,255,255,0.75);border-color:rgba(255,255,255,0.25);">About the Studio →</a>
        </div>
    </div>
    <div class="hero-right">
        <div class="hero-search-panel">
            <h2>Find What You Need</h2>
            <p>Search by product name, brand, or category</p>
            <form action="{{ route('search') }}" method="GET" class="hero-search-row">
                <input type="text" name="q" placeholder="e.g. monitor, keyboard, chair…" value="{{ request('q') }}">
                <button class="btn btn-teal">Search</button>
            </form>
        </div>
        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hero-stat-num">{{ $categories->count() }}</div>
                <div class="hero-stat-label">Categories</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-num">{{ $featuredProducts->count() }}+</div>
                <div class="hero-stat-label">Featured Items</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-num" style="color:var(--red);">3</div>
                <div class="hero-stat-label">Compare at once</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-num" style="color:var(--red);">Free</div>
                <div class="hero-stat-label">In-store browsing</div>
            </div>
        </div>
    </div>
</section>
{{-- TICKER --}}
<div class="ticker-wrap">
    <div class="ticker-track" id="tickerTrack">
        <span>Free In-Store Browsing</span>
        <span><em>✦</em></span>
        <span>Compare Up to <em>3 Products</em></span>
        <span><em>✦</em></span>
        <span>Ask Staff for a Demo</span>
        <span><em>✦</em></span>
        <span>New Arrivals Weekly</span>
        <span><em>✦</em></span>
        <span>Exclusive Studio Bundles</span>
        <span><em>✦</em></span>
        <span>Free In-Store Browsing</span>
        <span><em>✦</em></span>
        <span>Compare Up to <em>3 Products</em></span>
        <span><em>✦</em></span>
        <span>Ask Staff for a Demo</span>
        <span><em>✦</em></span>
        <span>New Arrivals Weekly</span>
        <span><em>✦</em></span>
        <span>Exclusive Studio Bundles</span>
        <span><em>✦</em></span>
    </div>
</div>

{{-- CATEGORIES --}}
<section style="margin-bottom: 4rem;">
    <div class="section-label">
        <div>
            <div class="section-divider"></div>
            <h2>Browse by Category</h2>
        </div>
        <a href="{{ route('search') }}">See all categories →</a>
    </div>
    <div class="cat-grid">
        @foreach($categories as $cat)
        <a href="{{ route('category.show', $cat) }}" class="cat-card">
            <div class="cat-icon">
                @if($cat->category_image)
                    <img src="{{ asset('storage/'.$cat->category_image) }}" alt="{{ $cat->category_name }}">
                @else
                    <svg width="24" height="24" fill="none" stroke="var(--teal)" stroke-width="1.5" viewBox="0 0 24 24">
                        <rect x="2" y="3" width="20" height="14" rx="2"/>
                        <path d="M8 21h8M12 17v4"/>
                    </svg>
                @endif
            </div>
            <p class="cat-name">{{ $cat->category_name }}</p>
            <p class="cat-count">{{ $cat->products_count }} products</p>
        </a>
        @endforeach
    </div>
</section>

{{-- PROMO STRIP --}}
<div class="promo-banner">
    <div class="promo-text">
        <h3>Not sure what to pick?<br>Our staff will walk you through it.</h3>
        <p>Ask any in-store associate for a hands-on demo of any product in our catalog.</p>
    </div>
    <a href="{{ route('faq') }}" class="promo-cta">Learn More →</a>
</div>

{{-- FEATURED PRODUCTS --}}
<section class="products-section">
    <div class="section-label">
        <div>
            <div class="section-divider"></div>
            <h2>Featured Products</h2>
        </div>
        <a href="{{ route('search') }}">View all →</a>
    </div>
    <div class="product-grid">
        @foreach($featuredProducts as $product)
            @include('partials.product-card', ['product' => $product])
        @endforeach
    </div>
</section>

@endsection