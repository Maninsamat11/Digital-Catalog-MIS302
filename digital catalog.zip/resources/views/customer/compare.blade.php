@extends('layouts.app')

@section('title', 'Compare Products — TechVault')

@section('content')

<div class="page-header">
    <h1>Compare Products</h1>
    <p>Side-by-side comparison</p>
</div>

@if($products->isEmpty())
    <div style="text-align:center;padding:4rem 0;">
        <p style="color:var(--muted);margin-bottom:1rem;">No products selected for comparison.</p>
        <a href="{{ route('home') }}" class="btn btn-primary">Browse Products</a>
    </div>
@else

<div style="overflow-x:auto;">
    <table style="min-width:600px;">
        <thead>
            <tr style="border-bottom:1px solid var(--border);">
                <th style="width:180px;color:var(--muted);">Specification</th>
                @foreach($products as $p)
                    <th>
                        <a href="{{ route('product.show', $p) }}" style="text-decoration:none;color:var(--text);">
                            <div style="margin-bottom:0.5rem;">
                                <img src="{{ asset('storage/'.$p->product_image) }}" alt="{{ $p->product_name }}"
                                     style="width:80px;height:80px;object-fit:cover;border-radius:10px;border:1px solid var(--border);">
                            </div>
                            <p style="font-family:'Syne',sans-serif;font-weight:600;font-size:0.9rem;">{{ $p->product_name }}</p>
                        </a>
                    </th>
                @endforeach
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Brand</td>
                @foreach($products as $p)
                    <td style="font-size:0.9rem;">{{ $p->brand }}</td>
                @endforeach
            </tr>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Category</td>
                @foreach($products as $p)
                    <td style="font-size:0.9rem;">{{ $p->category->category_name }}</td>
                @endforeach
            </tr>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Price</td>
                @foreach($products as $p)
                    <td style="font-size:1rem;font-weight:700;color:var(--accent);">${{ number_format($p->price, 2) }}</td>
                @endforeach
            </tr>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Stock</td>
                @foreach($products as $p)
                    <td style="font-size:0.9rem;">{{ $p->stock_quantity }} units</td>
                @endforeach
            </tr>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Status</td>
                @foreach($products as $p)
                    <td>
                        @if($p->status === 'available')
                            <span class="chip chip-green" style="font-size:0.75rem;">Available</span>
                        @else
                            <span class="chip chip-red" style="font-size:0.75rem;">Out of Stock</span>
                        @endif
                    </td>
                @endforeach
            </tr>
            <tr>
                <td style="color:var(--muted);font-size:0.85rem;">Description</td>
                @foreach($products as $p)
                    <td style="font-size:0.85rem;color:var(--muted);max-width:220px;">{{ Str::limit($p->description, 120) }}</td>
                @endforeach
            </tr>
            <tr>
                <td></td>
                @foreach($products as $p)
                    <td><a href="{{ route('product.show', $p) }}" class="btn btn-outline btn-sm">View Details</a></td>
                @endforeach
            </tr>
        </tbody>
    </table>
</div>

<div style="margin-top:2rem;text-align:center;">
    <button class="btn btn-outline" onclick="clearCompare();window.location='{{ route('home') }}'">
        Clear & Browse More
    </button>
</div>

@endif

@endsection
