<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Category;
use App\Models\UserInteraction;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        // 1. Basic Stats
        $totalProducts    = Product::count();
        $totalCategories  = Category::count();
        $outOfStock       = Product::where('status', 'out_of_stock')->count();
        $totalInteractions = UserInteraction::count();

        // 2. Top Performing Products (Calculates Views, Searches, and Compares separately)
        $topProducts = UserInteraction::with('product')
            ->select('product_id')
            ->selectRaw("SUM(CASE WHEN interaction_type = 'view' THEN 1 ELSE 0 END) as views_count")
            ->selectRaw("SUM(CASE WHEN interaction_type = 'search' THEN 1 ELSE 0 END) as search_count")
            ->selectRaw("SUM(CASE WHEN interaction_type = 'compare' THEN 1 ELSE 0 END) as compare_count")
            ->whereNotNull('product_id')
            ->groupBy('product_id')
            ->orderByRaw('views_count + search_count + compare_count DESC')
            ->take(5)
            ->get();

        // 3. Interactions by type (For the Progress Bars)
        $interactionsByType = UserInteraction::select('interaction_type', DB::raw('count(*) as count'))
            ->groupBy('interaction_type')
            ->pluck('count', 'interaction_type');

        // 4. Daily interactions (For the Chart - using interacted_at column)
        $dailyInteractions = UserInteraction::select(
                DB::raw('DATE(interacted_at) as date'),
                DB::raw('count(*) as count')
            )
            ->where('interacted_at', '>=', now()->subDays(7))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // 5. Popular categories (Optional: keep if you still want to use it elsewhere)
        $popularCategories = UserInteraction::select('products.category_id', DB::raw('count(*) as views'))
            ->join('products', 'products.id', '=', 'user_interactions.product_id')
            ->where('user_interactions.interaction_type', 'view')
            ->groupBy('products.category_id')
            ->orderByDesc('views')
            ->with('product.category')
            ->take(5)
            ->get();

        // Pass variables to the view
        return view('admin.dashboard', compact(
            'totalProducts', 
            'totalCategories', 
            'outOfStock', 
            'totalInteractions',
            'topProducts',       // This matches the variable in your Blade file
            'interactionsByType', 
            'popularCategories', 
            'dailyInteractions'
        ));
    }

    public function interactions()
{
    $allProducts = UserInteraction::with('product')
        ->select('product_id')
        ->selectRaw("SUM(CASE WHEN interaction_type = 'view' THEN 1 ELSE 0 END) as views_count")
        ->selectRaw("SUM(CASE WHEN interaction_type = 'search' THEN 1 ELSE 0 END) as search_count")
        ->selectRaw("SUM(CASE WHEN interaction_type = 'compare' THEN 1 ELSE 0 END) as compare_count")
        ->whereNotNull('product_id')
        ->groupBy('product_id')
        ->orderByRaw('views_count + search_count + compare_count DESC')
        ->paginate(20); // We use paginate so the page isn't too long

    return view('admin.interactions', compact('allProducts'));
}
}