<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Admin user
        User::firstOrCreate(
            ['email' => 'admin@techvault.com'],
            ['name' => 'Admin', 'password' => Hash::make('password')]
        );

        // ── CATEGORIES ──────────────────────────────────────────────
        $accessory    = Category::create(['category_name' => 'Accessory']);
        $cables       = Category::create(['category_name' => 'Cables']);
        $dacAmp       = Category::create(['category_name' => 'DAC / Amp']);
        $dongleDac    = Category::create(['category_name' => 'Dongle DAC']);
        $earbuds      = Category::create(['category_name' => 'Earbuds / Wireless']);
        $earphones    = Category::create(['category_name' => 'Earphones (Wired)']);
        $eartips      = Category::create(['category_name' => 'Eartips']);
        $headphones   = Category::create(['category_name' => 'Headphones']);
        $iems         = Category::create(['category_name' => 'IEMs']);
        $keyboards    = Category::create(['category_name' => 'Keyboards']);
        $mice         = Category::create(['category_name' => 'Mice']);
        $monitors     = Category::create(['category_name' => 'Monitors']);
        $musicPlayers = Category::create(['category_name' => 'Music Players']);
        $speakers     = Category::create(['category_name' => 'Speakers']);

        // ── PRODUCTS ────────────────────────────────────────────────

        // ACCESSORY
        Product::create(['category_id' => $accessory->id, 'product_name' => 'Headphone Stand Aluminum', 'brand' => 'Sievert', 'description' => 'Solid aluminum single headphone stand with non-slip base. Compatible with all over-ear headphones.', 'price' => 29.99, 'stock_quantity' => 40, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $accessory->id, 'product_name' => 'Portable DAP Leather Case', 'brand' => 'Dignis', 'description' => 'Handcrafted genuine leather case for digital audio players. Available in multiple colors, precise cutouts for all ports.', 'price' => 45.00, 'stock_quantity' => 18, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $accessory->id, 'product_name' => 'IEM Storage Case Hard Shell', 'brand' => 'Pelican', 'description' => 'Hard shell carry case with customizable foam interior. Waterproof and crushproof, fits most IEMs and cables.', 'price' => 19.99, 'stock_quantity' => 55, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $accessory->id, 'product_name' => '3.5mm to 6.35mm Adapter', 'brand' => 'Nobunaga Labs', 'description' => 'Gold-plated 3.5mm TRS to 6.35mm TRS headphone adapter. Short body design, low contact resistance.', 'price' => 8.50, 'stock_quantity' => 100, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // CABLES
        Product::create(['category_id' => $cables->id, 'product_name' => 'Effect Audio Ares S', 'brand' => 'Effect Audio', 'description' => '26AWG UP-OCC copper Litz cable. 2-pin 0.78mm connector, available in 3.5mm SE and 4.4mm balanced terminations.', 'price' => 89.00, 'stock_quantity' => 15, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $cables->id, 'product_name' => 'Kinera Gramr', 'brand' => 'Kinera', 'description' => 'High-purity silver-plated copper cable with 8-strand braid. MMCX termination, flexible and tangle-resistant.', 'price' => 49.00, 'stock_quantity' => 22, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $cables->id, 'product_name' => 'Tripowin Zonie', 'brand' => 'Tripowin', 'description' => '16-core silver-plated OFC cable. Ultra-soft earhook design, compatible with 2-pin 0.78mm IEMs. 4.4mm balanced.', 'price' => 35.00, 'stock_quantity' => 30, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $cables->id, 'product_name' => 'DUNU DUW-02S Modular Cable', 'brand' => 'DUNU', 'description' => 'Modular MMCX cable with Quick-Switch plug system. Swap between 3.5mm, 2.5mm, and 4.4mm terminations easily.', 'price' => 129.00, 'stock_quantity' => 10, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // DAC / AMP
        Product::create(['category_id' => $dacAmp->id, 'product_name' => 'Topping DX3 Pro+', 'brand' => 'Topping', 'description' => 'Desktop DAC/Amp combo with LDAC Bluetooth 5.0. ESS ES9038Q2M chip, 2000mW output, balanced XLR and 4.4mm outputs.', 'price' => 189.00, 'stock_quantity' => 12, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $dacAmp->id, 'product_name' => 'FiiO K7', 'brand' => 'FiiO', 'description' => 'Balanced desktop DAC/Amp with dual AKM AK4493SEQ chips. 2000mW at 32 ohm, supports PCM768kHz and DSD512.', 'price' => 219.00, 'stock_quantity' => 8, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $dacAmp->id, 'product_name' => 'SMSL SU-9 Ultra', 'brand' => 'SMSL', 'description' => 'Reference-grade desktop DAC using dual ES9039SPRO chips. MQA full decoder, balanced output, ultra-low noise floor.', 'price' => 349.00, 'stock_quantity' => 5, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $dacAmp->id, 'product_name' => 'Schiit Magni Heresy', 'brand' => 'Schiit', 'description' => 'Fully discrete headphone amplifier. 2.4W at 32 ohm, near-zero THD+N, simple and powerful for desktop use.', 'price' => 109.00, 'stock_quantity' => 14, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // DONGLE DAC
        Product::create(['category_id' => $dongleDac->id, 'product_name' => 'FiiO KA13', 'brand' => 'FiiO', 'description' => 'Dual CS43198 dongle DAC/amp with 4.4mm balanced output. 270mW at 32 ohm, supports PCM384kHz and DSD256.', 'price' => 79.00, 'stock_quantity' => 25, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $dongleDac->id, 'product_name' => 'Hidizs S9 Pro Plus', 'brand' => 'Hidizs', 'description' => 'ES9281AC Pro single chip dongle with 3.5mm and 2.5mm outputs. 200mW balanced, MQA 16x decoding support.', 'price' => 69.00, 'stock_quantity' => 18, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $dongleDac->id, 'product_name' => 'Cayin RU7', 'brand' => 'Cayin', 'description' => 'Premium 1-bit DSD dongle DAC using Rohm BD34301EKV chip. 4.4mm balanced, discrete output stage, audiophile-grade.', 'price' => 199.00, 'stock_quantity' => 7, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $dongleDac->id, 'product_name' => 'Apple USB-C to 3.5mm Adapter', 'brand' => 'Apple', 'description' => 'Official Apple DAC adapter for USB-C devices. Plug-and-play, 24-bit audio support, compact and lightweight.', 'price' => 12.00, 'stock_quantity' => 60, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // EARBUDS / WIRELESS
        Product::create(['category_id' => $earbuds->id, 'product_name' => 'Sony WF-1000XM5', 'brand' => 'Sony', 'description' => 'Flagship TWS earbuds with industry-leading ANC. LDAC support, 8hr battery plus 24hr case, IPX4 water resistant.', 'price' => 279.99, 'stock_quantity' => 20, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $earbuds->id, 'product_name' => 'Apple AirPods Pro 2', 'brand' => 'Apple', 'description' => 'H2 chip powered TWS with Adaptive Transparency and Personalized Spatial Audio. MagSafe charging case included.', 'price' => 249.00, 'stock_quantity' => 30, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $earbuds->id, 'product_name' => 'Samsung Galaxy Buds3 Pro', 'brand' => 'Samsung', 'description' => 'ANC TWS earbuds with blade-type design. 360 Audio, hi-fi 24-bit sound, 6hr playback plus 30hr with case.', 'price' => 229.99, 'stock_quantity' => 16, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $earbuds->id, 'product_name' => 'Nothing Ear (2)', 'brand' => 'Nothing', 'description' => 'Transparent-design TWS with dual-driver setup and LHDC 5.0. Personalized ANC, Hi-Res Audio certified.', 'price' => 149.00, 'stock_quantity' => 22, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // EARPHONES (WIRED)
        Product::create(['category_id' => $earphones->id, 'product_name' => 'Sennheiser IE 200', 'brand' => 'Sennheiser', 'description' => 'Audiophile wired earphone with TrueResponse transducer. Detachable 2-pin cable, 7Hz to 41kHz frequency response.', 'price' => 149.95, 'stock_quantity' => 14, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $earphones->id, 'product_name' => 'Audio-Technica ATH-E70', 'brand' => 'Audio-Technica', 'description' => 'Professional in-ear monitor with triple balanced armature drivers. MMCX connectors, 116dB sensitivity.', 'price' => 349.00, 'stock_quantity' => 6, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $earphones->id, 'product_name' => 'Shure SE215', 'brand' => 'Shure', 'description' => 'Sound-isolating earphone with single dynamic driver. Over-ear cable routing, up to 37dB isolation, MMCX detachable.', 'price' => 99.00, 'stock_quantity' => 25, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $earphones->id, 'product_name' => 'Final Audio E3000', 'brand' => 'Final Audio', 'description' => 'Stainless steel body earphone with 6.4mm dynamic driver. Natural warm sound signature, 3.5mm straight plug.', 'price' => 39.99, 'stock_quantity' => 35, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // EARTIPS
        Product::create(['category_id' => $eartips->id, 'product_name' => 'SpinFit CP145', 'brand' => 'SpinFit', 'description' => 'Patented rotating eartips with dual-layer silicone. Fits nozzles 4.5 to 5.5mm, improves seal and bass response.', 'price' => 14.99, 'stock_quantity' => 80, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $eartips->id, 'product_name' => 'Azla SednaEarfit Crystal', 'brand' => 'Azla', 'description' => 'Ultra-soft liquid silicone eartips with anti-slip coating. Available in XS/S/MS/M/ML/L sizes, 3 pairs per pack.', 'price' => 19.99, 'stock_quantity' => 60, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $eartips->id, 'product_name' => 'Final Audio Type E Eartips', 'brand' => 'Final Audio', 'description' => 'Premium silicone eartips used in Final Audio earphones. Low friction surface for comfortable long-wear sessions.', 'price' => 9.99, 'stock_quantity' => 100, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $eartips->id, 'product_name' => 'Comply Foam Tips T-200', 'brand' => 'Comply', 'description' => 'Memory foam eartips with Sweat-Guard technology. Superior isolation and comfort, fits most universal IEMs.', 'price' => 17.99, 'stock_quantity' => 70, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // HEADPHONES
        Product::create(['category_id' => $headphones->id, 'product_name' => 'Sony WH-1000XM5', 'brand' => 'Sony', 'description' => 'Over-ear ANC headphone with 30hr battery and multipoint connection. LDAC Hi-Res Wireless, foldable design.', 'price' => 349.99, 'stock_quantity' => 18, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $headphones->id, 'product_name' => 'Hifiman Sundara 2020', 'brand' => 'Hifiman', 'description' => 'Planar magnetic open-back headphone with NEO supernano diaphragm. 94dB sensitivity, 37 ohm impedance.', 'price' => 299.00, 'stock_quantity' => 9, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $headphones->id, 'product_name' => 'Sennheiser HD 560S', 'brand' => 'Sennheiser', 'description' => 'Open-back audiophile headphone with 120 ohm impedance. Wide soundstage, neutral tuning, detachable cable.', 'price' => 199.95, 'stock_quantity' => 11, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $headphones->id, 'product_name' => 'Beyerdynamic DT 770 Pro', 'brand' => 'Beyerdynamic', 'description' => 'Closed-back studio headphone available in 32/80/250 ohm variants. Excellent isolation, punchy bass, velour ear cushions.', 'price' => 159.00, 'stock_quantity' => 20, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // IEMs
        Product::create(['category_id' => $iems->id, 'product_name' => 'Moondrop Aria 2', 'brand' => 'Moondrop', 'description' => 'Single dynamic driver IEM with VDSF-tuned 10mm driver. Ultra-lightweight resin shell, 2-pin 0.78mm cable included.', 'price' => 79.99, 'stock_quantity' => 30, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $iems->id, 'product_name' => 'Truthear Hexa', 'brand' => 'Truthear', 'description' => '1DD + 3BA hybrid IEM co-developed with Crinacle. Harman-tuned, low distortion, comes with quality stock cable.', 'price' => 109.99, 'stock_quantity' => 20, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $iems->id, 'product_name' => 'Campfire Audio Supermoon', 'brand' => 'Campfire Audio', 'description' => 'Single planar magnetic IEM with liquid metal faceplate. Flat transparent tuning, ceramic body, MMCX connector.', 'price' => 699.00, 'stock_quantity' => 4, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $iems->id, 'product_name' => 'ThieAudio Oracle MKII', 'brand' => 'ThieAudio', 'description' => '2DD + 4BA hybrid IEM with resin shell. Reference tuning, wide soundstage, comes with premium silver-plated cable.', 'price' => 299.00, 'stock_quantity' => 8, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // KEYBOARDS
        Product::create(['category_id' => $keyboards->id, 'product_name' => 'Keychron Q1 Pro', 'brand' => 'Keychron', 'description' => 'Full aluminum 75% wireless mechanical keyboard. QMK/VIA support, gasket-mounted, hot-swappable PCB, RGB backlight.', 'price' => 199.00, 'stock_quantity' => 15, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $keyboards->id, 'product_name' => 'Logitech MX Keys S', 'brand' => 'Logitech', 'description' => 'Advanced wireless keyboard with smart illumination. Multi-OS layout, USB-C rechargeable, quiet tactile keys.', 'price' => 119.99, 'stock_quantity' => 22, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $keyboards->id, 'product_name' => 'Akko 5075B Plus', 'brand' => 'Akko', 'description' => '75% Bluetooth + USB-C hot-swap keyboard with south-facing RGB. Gasket structure, pre-lubed Akko CS switches.', 'price' => 89.99, 'stock_quantity' => 18, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $keyboards->id, 'product_name' => 'Ducky One 3 Mini', 'brand' => 'Ducky', 'description' => '60% hot-swap mechanical keyboard with triple-layer dampening foam. USB-C, doubleshot PBT keycaps, Cherry MX switches.', 'price' => 109.00, 'stock_quantity' => 0, 'product_image' => 'products/placeholder.jpg', 'status' => 'out_of_stock']);

        // MICE
        Product::create(['category_id' => $mice->id, 'product_name' => 'Logitech G Pro X Superlight 2', 'brand' => 'Logitech', 'description' => 'Ultra-lightweight wireless gaming mouse at 60g. HERO 2 sensor 32K DPI, LIGHTSPEED wireless, 95hr battery.', 'price' => 159.99, 'stock_quantity' => 20, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $mice->id, 'product_name' => 'Razer Viper V3 HyperSpeed', 'brand' => 'Razer', 'description' => 'Asymmetric wireless gaming mouse with Focus X 30K sensor. HyperSpeed low-latency, up to 279hr battery life.', 'price' => 79.99, 'stock_quantity' => 25, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $mice->id, 'product_name' => 'Glorious Model O 2 Wireless', 'brand' => 'Glorious', 'description' => 'Honeycomb design wireless mouse at 59g. BAMF 2.0 26K sensor, 210hr battery, flexible Ascended Cord included.', 'price' => 89.99, 'stock_quantity' => 12, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $mice->id, 'product_name' => 'Pulsar X2V2', 'brand' => 'Pulsar', 'description' => 'Symmetrical ultra-light wireless mouse at 55g. PAW3395 sensor, 26K DPI, 70hr battery, premium PTFE feet.', 'price' => 99.99, 'stock_quantity' => 10, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // MONITORS
        Product::create(['category_id' => $monitors->id, 'product_name' => 'LG UltraGear 27GP850-B', 'brand' => 'LG', 'description' => '27" QHD 165Hz Nano IPS gaming monitor. 1ms GtG, NVIDIA G-Sync Compatible, sRGB 98%, USB-C 90W PD.', 'price' => 399.99, 'stock_quantity' => 7, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $monitors->id, 'product_name' => 'Samsung Odyssey G7 32"', 'brand' => 'Samsung', 'description' => '32" 4K 144Hz QLED curved gaming monitor. DisplayHDR 600, 1ms response, G-Sync and FreeSync Premium Pro.', 'price' => 699.99, 'stock_quantity' => 4, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $monitors->id, 'product_name' => 'Dell UltraSharp U2723QE', 'brand' => 'Dell', 'description' => '27" 4K IPS Black professional monitor. 2000:1 contrast, 100% sRGB, USB-C 90W, built-in KVM switch.', 'price' => 579.99, 'stock_quantity' => 6, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $monitors->id, 'product_name' => 'ASUS ROG Swift PG27AQN', 'brand' => 'ASUS', 'description' => '27" QHD 360Hz Fast IPS esports monitor. G-Sync Ultimate, 1ms, ELMB Sync, built-in ASUS Aura RGB lighting.', 'price' => 849.99, 'stock_quantity' => 0, 'product_image' => 'products/placeholder.jpg', 'status' => 'out_of_stock']);

        // MUSIC PLAYERS
        Product::create(['category_id' => $musicPlayers->id, 'product_name' => 'FiiO M11 Plus', 'brand' => 'FiiO', 'description' => 'Android-based DAP with dual AK4497EQ chips. 4.4mm and 3.5mm outputs, 4GB RAM, Wi-Fi and Bluetooth 5.0.', 'price' => 549.00, 'stock_quantity' => 8, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $musicPlayers->id, 'product_name' => 'Shanling M3 Ultra', 'brand' => 'Shanling', 'description' => 'Compact Android DAP with ES9219C chip. 4.4mm balanced output, 3.5mm SE, Bluetooth 5.0 with LDAC and aptX.', 'price' => 329.00, 'stock_quantity' => 10, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $musicPlayers->id, 'product_name' => 'HiBy R6 Pro II', 'brand' => 'HiBy', 'description' => 'Dual ES9038Q2M flagship DAP with Darwin Architecture amplifier. Android 12, Wi-Fi 6, MQA full decoder.', 'price' => 699.00, 'stock_quantity' => 5, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $musicPlayers->id, 'product_name' => 'Sony NW-A306 Walkman', 'brand' => 'Sony', 'description' => 'Compact Android Walkman with S-Master HX amp. DSEE Ultimate upscaling, 5" OLED display, 36hr battery life.', 'price' => 359.99, 'stock_quantity' => 12, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);

        // SPEAKERS
        Product::create(['category_id' => $speakers->id, 'product_name' => 'KEF LSX II', 'brand' => 'KEF', 'description' => 'Wireless HiFi bookshelf speakers with Uni-Q driver. Wi-Fi, Bluetooth, optical and USB-C inputs, 200W total power.', 'price' => 1099.00, 'stock_quantity' => 5, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $speakers->id, 'product_name' => 'Edifier R1280DBs', 'brand' => 'Edifier', 'description' => 'Active bookshelf speaker with Bluetooth 5.0 and optical/coax/AUX inputs. 42W RMS, DSP processing, subwoofer output.', 'price' => 139.99, 'stock_quantity' => 20, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $speakers->id, 'product_name' => 'JBL Charge 5', 'brand' => 'JBL', 'description' => 'Portable Bluetooth 5.1 speaker with IP67 waterproofing. 20hr battery, USB-A charging out, JBL PartyBoost support.', 'price' => 179.95, 'stock_quantity' => 28, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
        Product::create(['category_id' => $speakers->id, 'product_name' => 'Sonos Era 300', 'brand' => 'Sonos', 'description' => 'Spatial audio smart speaker with Dolby Atmos support. 6 drivers, Wi-Fi and Bluetooth, Apple AirPlay 2, line-in USB-C.', 'price' => 449.00, 'stock_quantity' => 9, 'product_image' => 'products/placeholder.jpg', 'status' => 'available']);
    }
}